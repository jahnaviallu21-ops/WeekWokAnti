# 🏛️ WeekWok: 3-Tier System Design & Architecture Document

## 1. System Design Paradigm

WeekWok follows a decoupled, robust 3-Tier Enterprise Architecture:

```
+-----------------------------------------------------------+
|               TIER 1: PRESENTATION LAYER                  |
|  - HTML5 / CSS3 / ES6 Modular JavaScript (Production)     |
|  - React 19 + TypeScript + Custom Hooks (Dynamic Phase)   |
+-----------------------------------------------------------+
                             │
                             ▼ HTTP / REST
+-----------------------------------------------------------+
|               TIER 2: APPLICATION BACKEND                 |
|  - Node.js & Express REST Controllers                     |
|  - Security Middleware (CORS, Helmet, Rate Limiter)       |
|  - SRS 3.3 Pantry Deduction & Restitution Engine          |
+-----------------------------------------------------------+
                             │
                             ▼ Prepared Statements
+-----------------------------------------------------------+
|               TIER 3: DATABASE TIER                       |
|  - SQLite 3 Relational Engine (Prepared Statements)       |
|  - Relational Schema (users, recipes, pantry, plans)      |
+-----------------------------------------------------------+
```

## 2. Relational Database Entity-Relationship Model

```
[ users ]
   ├── id (PK, INTEGER)
   ├── username (TEXT, UNIQUE)
   ├── kitchen_name (TEXT)
   └── dietary_preference (TEXT)
          │
          ├──< [ pantry_items ] (1-to-Many)
          │       ├── id (PK, INTEGER)
          │       ├── name (TEXT)
          │       ├── quantity (REAL)
          │       ├── unit (TEXT)
          │       └── expiry (DATE)
          │
          ├──< [ meal_plans ] (1-to-Many)
          │       ├── id (PK, INTEGER)
          │       ├── day_index (INTEGER, 0-6)
          │       ├── slot_index (INTEGER, 0-2)
          │       ├── recipe_id (FK -> recipes.id)
          │       └── status (TEXT: 'scheduled' | 'completed')
          │
          └──< [ stock_transactions ] (1-to-Many Audit Trail)
                  ├── id (PK, INTEGER)
                  ├── plan_key (TEXT)
                  ├── ingredient_name (TEXT)
                  ├── quantity_changed (REAL)
                  └── action_type ('SCHEDULE_DEDUCT' | 'RESTITUTION')
```

## 3. Security & Robustness Measures
- **SQL Injection Prevention**: All queries use parameterized inputs and prepared statements.
- **XSS Sanitization**: User inputs are escaped via strict entity encoding before DOM insertion.
- **Payload Limiting**: Express server caps request payload size to 1MB to prevent memory exhaustion.
- **Defensive Type Safety**: Strict null-checks on every recipe lookup and date computation prevent runtime TypeError crashes.
