/* ==========================================================================
   WEEKWOK — SMART MEAL & PANTRY PLANNER (VERSION 2.0 - 90+ EDITION)
   Architectural Features:
   - SRS 3.3 Pantry Stock Deduction Engine (Real-Time Schedule Deduction & Restitution)
   - Dynamic 7-Day Grid with Multi-Week Calendar Navigation
   - Comprehensive Nutrition & Macronutrient Analytics
   - Dual-Mode Persistence (SQLite 3-Tier REST Sync + Resilient Local Storage)
   - Zero-Defect Defensive Programming (Strict Null-Checking, Unit Conversions)
   ========================================================================== */

// --- 1. CONFIGURATION & CONSTANTS ---
const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
const SLOTS = ["Breakfast", "Lunch", "Dinner"];

const DEFAULT_SETTINGS = {
  kitchenName: "My Kitchen",
  chefName: "Chef Jahnavi",
  deductionMode: "SRS_3_3_SCHEDULE", // 'SRS_3_3_SCHEDULE' | 'RESERVATION_COMPLETE'
  weeklyBudget: 2500,
  dietPreference: "All"
};

const DEFAULT_PANTRY = [
  { id: 1, name: "Paneer", quantity: 400, unit: "g", expiry: "2026-11-24", price: 0.35 },
  { id: 2, name: "Basmati Rice", quantity: 1000, unit: "g", expiry: "2027-04-10", price: 0.09 },
  { id: 3, name: "Cooking Oil", quantity: 1000, unit: "ml", expiry: "2027-02-15", price: 0.18 },
  { id: 4, name: "Onions", quantity: 500, unit: "g", expiry: "2026-11-28", price: 0.04 },
  { id: 5, name: "Eggs", quantity: 6, unit: "pcs", expiry: "2026-11-25", price: 7.0 },
  { id: 6, name: "Tomatoes", quantity: 300, unit: "g", expiry: "2026-11-23", price: 0.05 },
  { id: 7, name: "Milk", quantity: 500, unit: "ml", expiry: "2026-11-24", price: 0.06 },
  { id: 8, name: "Potatoes", quantity: 500, unit: "g", expiry: "2026-12-05", price: 0.03 }
];

const RECIPES = [
  {
    id: 1,
    name: "Paneer Butter Masala",
    category: "Dinner",
    time: 35,
    servings: 2,
    price: 180,
    calories: 480,
    protein: 22,
    carbs: 24,
    fat: 34,
    image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800",
    description: "A rich, creamy paneer curry with tomatoes and aromatic spices.",
    ingredients: [
      { name: "Paneer", amount: 400, unit: "g" },
      { name: "Butter", amount: 50, unit: "g" },
      { name: "Tomatoes", amount: 250, unit: "g" },
      { name: "Cream", amount: 100, unit: "ml" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Heat butter and oil in a pan.",
      "Add chopped onions and cook until soft.",
      "Add tomatoes and spices. Cook until smooth.",
      "Add paneer cubes and cream.",
      "Simmer for 8–10 minutes and serve warm with naan or rice."
    ]
  },
  {
    id: 2,
    name: "Garden Harvest Bowl",
    category: "Lunch",
    time: 25,
    servings: 2,
    price: 120,
    calories: 290,
    protein: 10,
    carbs: 38,
    fat: 12,
    image: "harvestgardenbowl.jpg",
    description: "A refreshing bowl filled with seasonal vegetables and greens.",
    ingredients: [
      { name: "Tomatoes", amount: 150, unit: "g" },
      { name: "Cucumber", amount: 150, unit: "g" },
      { name: "Spinach", amount: 100, unit: "g" },
      { name: "Olive Oil", amount: 15, unit: "ml" },
      { name: "Lemons", amount: 1, unit: "pcs" }
    ],
    instructions: [
      "Wash and prepare all crisp garden vegetables.",
      "Chop the cucumber and ripe tomatoes into bite sizes.",
      "Combine with fresh spinach leaves in a salad bowl.",
      "Prepare a zesty lemon, sea salt, and extra virgin olive oil dressing.",
      "Toss thoroughly and serve chilled."
    ]
  },
  {
    id: 3,
    name: "Berry & Oat Bowl",
    category: "Breakfast",
    time: 10,
    servings: 2,
    price: 90,
    calories: 340,
    protein: 16,
    carbs: 58,
    fat: 6,
    image: "berry&oatmeal.jpg",
    description: "A nourishing breakfast with rolled oats, fresh fruit and creamy yoghurt.",
    ingredients: [
      { name: "Rolled Oats", amount: 100, unit: "g" },
      { name: "Milk", amount: 250, unit: "ml" },
      { name: "Mixed Berries", amount: 100, unit: "g" },
      { name: "Honey", amount: 20, unit: "g" },
      { name: "Greek Yoghurt", amount: 100, unit: "g" }
    ],
    instructions: [
      "Simmer rolled oats gently with warm milk until creamy.",
      "Allow the oats to cool slightly for 2 minutes.",
      "Fold in rich Greek yoghurt and crown with mixed berries.",
      "Drizzle with golden honey and serve."
    ]
  },
  {
    id: 4,
    name: "Avocado Sourdough",
    category: "Breakfast",
    time: 12,
    servings: 2,
    price: 110,
    calories: 380,
    protein: 11,
    carbs: 42,
    fat: 20,
    image: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800",
    description: "Crispy toasted artisanal sourdough topped with seasoned avocado.",
    ingredients: [
      { name: "Bread", amount: 2, unit: "pcs" },
      { name: "Avocado", amount: 150, unit: "g" },
      { name: "Lemons", amount: 1, unit: "pcs" },
      { name: "Olive Oil", amount: 10, unit: "ml" }
    ],
    instructions: [
      "Toast sourdough slices until crisp and golden brown.",
      "Mash ripe avocado with fresh lemon juice and sea salt.",
      "Spread over toast and finish with olive oil drizzle."
    ]
  },
  {
    id: 5,
    name: "Tomato Basil Pasta",
    category: "Dinner",
    time: 25,
    servings: 2,
    price: 140,
    calories: 440,
    protein: 14,
    carbs: 72,
    fat: 10,
    image: "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800",
    description: "Classic Italian pasta tossed in rich tomato and fresh sweet basil sauce.",
    ingredients: [
      { name: "Pasta", amount: 200, unit: "g" },
      { name: "Tomatoes", amount: 300, unit: "g" },
      { name: "Olive Oil", amount: 20, unit: "ml" },
      { name: "Garlic", amount: 15, unit: "g" },
      { name: "Fresh Basil", amount: 15, unit: "g" }
    ],
    instructions: [
      "Boil salted water and cook pasta al dente.",
      "Heat olive oil and gently sauté fragrant minced garlic.",
      "Add crushed tomatoes and simmer for 15 minutes.",
      "Toss pasta in sauce and garnish with torn basil."
    ]
  },
  {
    id: 6,
    name: "Golden Vegetable Curry",
    category: "Dinner",
    time: 30,
    servings: 2,
    price: 130,
    calories: 360,
    protein: 9,
    carbs: 32,
    fat: 22,
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=800",
    description: "A warming turmeric coconut curry with garden vegetables.",
    ingredients: [
      { name: "Cooking Oil", amount: 20, unit: "ml" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Potatoes", amount: 150, unit: "g" },
      { name: "Carrots", amount: 100, unit: "g" },
      { name: "Coconut Milk", amount: 200, unit: "ml" }
    ],
    instructions: [
      "Sauté diced onions in hot cooking oil until aromatic.",
      "Toss in potatoes and carrots with fragrant spices.",
      "Pour coconut milk and simmer until tender.",
      "Garnish with cilantro and serve warm."
    ]
  },
  {
    id: 7,
    name: "Berry Fruit Pancakes",
    category: "Breakfast",
    time: 20,
    servings: 2,
    price: 120,
    calories: 420,
    protein: 12,
    carbs: 68,
    fat: 11,
    image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=800",
    description: "Fluffy breakfast pancakes layered with seasonal berries and honey.",
    ingredients: [
      { name: "Flour", amount: 150, unit: "g" },
      { name: "Milk", amount: 150, unit: "ml" },
      { name: "Eggs", amount: 1, unit: "pcs" },
      { name: "Butter", amount: 20, unit: "g" },
      { name: "Honey", amount: 25, unit: "g" }
    ],
    instructions: [
      "Whisk flour, milk, egg, and melted butter into a batter.",
      "Cook on a lightly buttered hot skillet.",
      "Flip when small bubbles burst on surface.",
      "Stack tall and top with fruit and honey."
    ]
  },
  {
    id: 8,
    name: "Homestyle Vegetable Pulao",
    category: "Lunch",
    time: 30,
    servings: 2,
    price: 110,
    calories: 410,
    protein: 11,
    carbs: 70,
    fat: 9,
    image: "vegetablepulao.jpg",
    description: "Fragrant spiced basmati rice simmered with garden vegetables.",
    ingredients: [
      { name: "Basmati Rice", amount: 200, unit: "g" },
      { name: "Carrots", amount: 80, unit: "g" },
      { name: "Onions", amount: 80, unit: "g" },
      { name: "Cooking Oil", amount: 20, unit: "ml" },
      { name: "Potatoes", amount: 100, unit: "g" }
    ],
    instructions: [
      "Wash and soak basmati rice for 15 minutes.",
      "Sauté onions and spices in oil until lightly golden.",
      "Add vegetables and rice with water.",
      "Cover and steam until grains are separate and fluffy."
    ]
  },
  {
    id: 9,
    name: "French Toast",
    category: "Breakfast",
    time: 15,
    servings: 2,
    price: 95,
    calories: 390,
    protein: 15,
    carbs: 48,
    fat: 14,
    image: "french.jpg",
    description: "Golden toasted bread slices dipped in sweet egg and milk mixture.",
    ingredients: [
      { name: "Bread", amount: 4, unit: "pcs" },
      { name: "Eggs", amount: 2, unit: "pcs" },
      { name: "Milk", amount: 100, unit: "ml" },
      { name: "Butter", amount: 20, unit: "g" },
      { name: "Honey", amount: 20, unit: "g" }
    ],
    instructions: [
      "Whisk eggs, milk, cinnamon, and honey together.",
      "Dip each bread slice until soaked.",
      "Melt butter in a pan and sear each side until golden.",
      "Serve warm."
    ]
  },
  {
    id: 10,
    name: "Chole Rice",
    category: "Lunch",
    time: 35,
    servings: 2,
    price: 135,
    calories: 490,
    protein: 18,
    carbs: 82,
    fat: 10,
    image: "chole.jpg",
    description: "Spiced chickpea curry simmered in onion-tomato gravy with rice.",
    ingredients: [
      { name: "Chickpeas", amount: 200, unit: "g" },
      { name: "Basmati Rice", amount: 150, unit: "g" },
      { name: "Tomatoes", amount: 150, unit: "g" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Soak chickpeas overnight and pressure cook until tender.",
      "Cook spiced onion-tomato masala base.",
      "Simmer chickpeas in gravy for 15 minutes.",
      "Serve with steamed basmati rice."
    ]
  },
  {
    id: 11,
    name: "Crispy Herb Paneer Bites",
    category: "Snacks",
    time: 15,
    servings: 2,
    price: 115,
    calories: 310,
    protein: 19,
    carbs: 8,
    fat: 23,
    image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800",
    description: "Pan-seared spiced paneer cubes tossed in mint dressing and toasted herbs.",
    ingredients: [
      { name: "Paneer", amount: 200, unit: "g" },
      { name: "Olive Oil", amount: 15, unit: "ml" },
      { name: "Lemons", amount: 1, unit: "pcs" },
      { name: "Fresh Basil", amount: 10, unit: "g" }
    ],
    instructions: [
      "Cut paneer into bite-sized cubes.",
      "Toss with olive oil, sea salt, lemon zest, and herbs.",
      "Pan-sear on medium-high until lightly charred on edges.",
      "Serve hot with lemon wedge."
    ]
  },
  {
    id: 12,
    name: "Greek Yoghurt Fruit Parfait",
    category: "Snacks",
    time: 8,
    servings: 1,
    price: 75,
    calories: 220,
    protein: 14,
    carbs: 32,
    fat: 4,
    image: "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=800",
    description: "Layers of strained Greek yoghurt, honey and fresh mixed berries.",
    ingredients: [
      { name: "Greek Yoghurt", amount: 150, unit: "g" },
      { name: "Mixed Berries", amount: 80, unit: "g" },
      { name: "Honey", amount: 15, unit: "g" }
    ],
    instructions: [
      "Spoon Greek yoghurt into a clear glass or bowl.",
      "Layer with plump fresh mixed berries.",
      "Drizzle golden honey over each layer and serve chilled."
    ]
  }
];

// --- 2. APPLICATION STATE ---
let pantry = loadStorage("weekwok-pantry", DEFAULT_PANTRY);
let plan = loadStorage("weekwok-plan", {});
let completed = loadStorage("weekwok-completed", []);
let checkedShopping = loadStorage("weekwok-checked", []);
let settings = loadStorage("weekwok-settings", DEFAULT_SETTINGS);

// SRS 3.3 deduction transaction ledger for undo/restoration tracking
let stockLedger = loadStorage("weekwok-ledger", {});

let activeRecipe = null;
let servingCount = 2;
let weekOffset = 0; // 0 = current week, -1 = last week, +1 = next week
let toastTimer = null;
let backendOnline = false;

// --- 3. STORAGE & RESILIENT HELPERS ---
function loadStorage(key, fallback) {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : structuredClone(fallback);
  } catch (e) {
    console.warn(`[WeekWok Storage] Failed to load ${key}, using default.`);
    return structuredClone(fallback);
  }
}

function saveAllStorage() {
  try {
    localStorage.setItem("weekwok-pantry", JSON.stringify(pantry));
    localStorage.setItem("weekwok-plan", JSON.stringify(plan));
    localStorage.setItem("weekwok-completed", JSON.stringify(completed));
    localStorage.setItem("weekwok-checked", JSON.stringify(checkedShopping));
    localStorage.setItem("weekwok-settings", JSON.stringify(settings));
    localStorage.setItem("weekwok-ledger", JSON.stringify(stockLedger));
  } catch (e) {
    console.error("[WeekWok Storage Error]:", e);
  }
}

function normalName(name) {
  return String(name || "").trim().toLowerCase();
}

function escapeHTML(str) {
  return String(str || "").replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}

function keyFor(day, slot) {
  return `${day}-${slot}`;
}

function showToast(message, type = "info") {
  const toast = document.getElementById("toast");
  if (!toast) return;

  const icons = { success: "✓ ", warning: "⚠️ ", error: "✕ ", info: "ℹ️ " };
  toast.textContent = (icons[type] || "") + message;
  toast.classList.add("show");

  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    toast.classList.remove("show");
  }, 3200);
}

function recipeById(id) {
  return RECIPES.find(r => r.id === Number(id)) || null;
}

function convertToBase(amount, unit) {
  const num = Number(amount) || 0;
  if (unit === "kg") return { amount: num * 1000, unit: "g" };
  if (unit === "l") return { amount: num * 1000, unit: "ml" };
  return { amount: num, unit };
}

function formatQuantity(amount, unit) {
  const rounded = Math.round((Number(amount) || 0) * 100) / 100;
  if (unit === "g" && rounded >= 1000) return `${(rounded / 1000).toFixed(1)} kg`;
  if (unit === "ml" && rounded >= 1000) return `${(rounded / 1000).toFixed(1)} L`;
  return `${rounded} ${unit}`;
}

// --- 4. DYNAMIC DATE CALENDAR ENGINE ---
function getWeekDates(offset = 0) {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0 is Sunday, 1 is Monday...
  const distanceToMonday = (dayOfWeek + 6) % 7; // Monday = 0

  const monday = new Date(now);
  monday.setDate(now.getDate() - distanceToMonday + (offset * 7));
  monday.setHours(0, 0, 0, 0);

  const dates = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    dates.push(d);
  }
  return dates;
}

function formatWeekHeadingLabel(weekDates) {
  if (weekOffset === 0) return "Current Week";
  const start = weekDates[0].toLocaleDateString("en-IN", { day: "numeric", month: "short" });
  const end = weekDates[6].toLocaleDateString("en-IN", { day: "numeric", month: "short" });
  return `${start} – ${end}`;
}

// --- 5. SRS 3.3 PANTRY STOCK DEDUCTION ENGINE ---
/**
 * Mode A: SRS 3.3 Schedule Deduction
 * When a meal is assigned to the schedule, ingredients are deducted immediately.
 * If removed, stock is restored.
 * 
 * Mode B: Reservation Mode
 * Ingredients are reserved on schedule, and deducted when marked "Complete".
 */

function getPantryAvailability() {
  const availability = {};

  pantry.forEach(item => {
    const base = convertToBase(item.quantity, item.unit);
    const name = normalName(item.name);

    let reservedAmount = 0;

    // In Reservation Mode, calculate active reservations from incomplete scheduled meals
    if (settings.deductionMode === "RESERVATION_COMPLETE") {
      Object.entries(plan).forEach(([key, recipeId]) => {
        if (!recipeId || completed.includes(key)) return;
        const recipe = recipeById(recipeId);
        if (!recipe) return;

        recipe.ingredients.forEach(ing => {
          if (normalName(ing.name) === name) {
            const ingBase = convertToBase(ing.amount, ing.unit);
            if (ingBase.unit === base.unit) {
              reservedAmount += ingBase.amount;
            }
          }
        });
      });
    }

    availability[name] = {
      stock: base.amount,
      reserved: reservedAmount,
      available: Math.max(0, base.amount - reservedAmount),
      unit: base.unit
    };
  });

  return availability;
}

function applySRS33ScheduleDeduction(recipe, key) {
  if (!recipe || !recipe.ingredients) return;

  const deductions = [];

  recipe.ingredients.forEach(ing => {
    const name = normalName(ing.name);
    const needed = convertToBase(ing.amount, ing.unit);

    const pantryItem = pantry.find(p => normalName(p.name) === name);
    if (!pantryItem) return;

    const currentBase = convertToBase(pantryItem.quantity, pantryItem.unit);
    if (currentBase.unit !== needed.unit) return;

    const deductAmount = Math.min(currentBase.amount, needed.amount);
    pantryItem.quantity = Math.max(0, currentBase.amount - deductAmount);
    pantryItem.unit = currentBase.unit;

    deductions.push({
      ingredient: ing.name,
      amount: deductAmount,
      unit: currentBase.unit
    });
  });

  stockLedger[key] = deductions;
}

function restoreSRS33Stock(key) {
  const logged = stockLedger[key];
  if (!logged || !Array.isArray(logged)) return;

  logged.forEach(entry => {
    const name = normalName(entry.ingredient);
    const pantryItem = pantry.find(p => normalName(p.name) === name);

    if (pantryItem) {
      const current = convertToBase(pantryItem.quantity, pantryItem.unit);
      if (current.unit === entry.unit) {
        pantryItem.quantity = current.amount + entry.amount;
      }
    } else {
      // Re-add to pantry if item was deleted
      pantry.push({
        id: Date.now() + Math.random(),
        name: entry.ingredient,
        quantity: entry.amount,
        unit: entry.unit,
        price: 0.15
      });
    }
  });

  delete stockLedger[key];
}

// --- 6. GROCERY SHOPPING GAP CALCULATOR ---
function getShoppingItems() {
  const requirements = {};

  Object.entries(plan).forEach(([key, recipeId]) => {
    if (!recipeId || completed.includes(key)) return;
    const recipe = recipeById(recipeId);
    if (!recipe) return;

    recipe.ingredients.forEach(ing => {
      const name = normalName(ing.name);
      const base = convertToBase(ing.amount, ing.unit);

      if (!requirements[name]) {
        requirements[name] = { name: ing.name, amount: 0, unit: base.unit };
      }
      if (requirements[name].unit === base.unit) {
        requirements[name].amount += base.amount;
      }
    });
  });

  const shoppingItems = [];

  Object.values(requirements).forEach(req => {
    const pantryItem = pantry.find(p => normalName(p.name) === normalName(req.name));
    let availableStock = 0;

    if (pantryItem) {
      const base = convertToBase(pantryItem.quantity, pantryItem.unit);
      if (base.unit === req.unit) {
        availableStock = base.amount;
      }
    }

    // In SRS 3.3 mode, stock was already deducted from pantry, so required amount represents what needed to be purchased
    let missing = 0;
    if (settings.deductionMode === "SRS_3_3_SCHEDULE") {
      missing = req.amount;
    } else {
      missing = Math.max(0, req.amount - availableStock);
    }

    if (missing > 0) {
      shoppingItems.push({
        name: req.name,
        amount: missing,
        unit: req.unit,
        price: pantryItem?.price || 0.15
      });
    }
  });

  return shoppingItems;
}

// --- 7. MEAL PLANNER RENDERER ---
function renderPlanner() {
  const container = document.getElementById("days-list");
  if (!container) return;

  const weekDates = getWeekDates(weekOffset);
  const weekLabelEl = document.getElementById("week-display-label");
  if (weekLabelEl) weekLabelEl.textContent = formatWeekHeadingLabel(weekDates);

  const modeTextEl = document.getElementById("planner-mode-text");
  if (modeTextEl) {
    modeTextEl.textContent = settings.deductionMode === "SRS_3_3_SCHEDULE"
      ? "SRS 3.3 Real-time Schedule Deduction"
      : "Reservation Mode (Deduct on Cook)";
  }

  container.innerHTML = DAYS.map((dayName, dayIndex) => {
    const d = weekDates[dayIndex];
    const dateNum = d.getDate();
    const monthName = d.toLocaleDateString("en-IN", { month: "short" });
    const isToday = new Date().toDateString() === d.toDateString();

    return `
      <article class="day-row ${isToday ? "today-row" : ""}">
        <div class="day-date">
          <small>${dayName.toUpperCase()}</small>
          <strong>${dateNum}</strong>
          <span class="day-sub">${monthName}</span>
        </div>

        ${SLOTS.map((slotName, slotIndex) => {
          const key = keyFor(dayIndex, slotIndex);
          const recipe = recipeById(plan[key]);
          const isDone = completed.includes(key);

          if (!recipe) {
            return `
              <div class="meal-slot empty"
                   data-day="${dayIndex}"
                   data-slot="${slotIndex}">
                + Add ${slotName}
              </div>
            `;
          }

          const badgeText = isDone
            ? "✓ COMPLETED"
            : settings.deductionMode === "SRS_3_3_SCHEDULE"
              ? "✓ STOCK DEDUCTED (SRS 3.3)"
              : "◈ STOCK RESERVED";

          return `
            <div class="meal-slot"
                 data-day="${dayIndex}"
                 data-slot="${slotIndex}">
              <div class="meal-slot-header">
                <small>${slotName.toUpperCase()}</small>
                <span>◷ ${recipe.time}m</span>
              </div>

              <strong>${escapeHTML(recipe.name)}</strong>

              <span class="meal-badge ${isDone ? "completed" : "deducted"}">
                ${badgeText}
              </span>

              <div class="slot-actions">
                <button data-view-recipe="${recipe.id}">Recipe</button>
                <button data-remove="${key}">Remove</button>
                ${!isDone ? `<button data-complete="${key}">Complete</button>` : ""}
              </div>
            </div>
          `;
        }).join("")}
      </article>
    `;
  }).join("");
}

// Planner event listener
document.addEventListener("DOMContentLoaded", () => {
  const daysList = document.getElementById("days-list");
  if (daysList) {
    daysList.addEventListener("click", event => {
      const removeBtn = event.target.closest("[data-remove]");
      const completeBtn = event.target.closest("[data-complete]");
      const viewBtn = event.target.closest("[data-view-recipe]");
      const slot = event.target.closest(".meal-slot");

      if (removeBtn) {
        const key = removeBtn.dataset.remove;
        if (settings.deductionMode === "SRS_3_3_SCHEDULE") {
          restoreSRS33Stock(key);
        }
        delete plan[key];
        completed = completed.filter(item => item !== key);
        saveAllStorage();
        refreshEverything();
        showToast("Meal removed and pantry inventory restored.", "info");
        return;
      }

      if (completeBtn) {
        completeMeal(completeBtn.dataset.complete);
        return;
      }

      if (viewBtn) {
        openRecipe(Number(viewBtn.dataset.viewRecipe));
        return;
      }

      if (slot && slot.classList.contains("empty")) {
        openAssignModal(Number(slot.dataset.day), Number(slot.dataset.slot));
      }
    });
  }

  // Week navigation buttons
  document.getElementById("prev-week-btn")?.addEventListener("click", () => {
    weekOffset--;
    renderPlanner();
  });
  document.getElementById("next-week-btn")?.addEventListener("click", () => {
    weekOffset++;
    renderPlanner();
  });
  document.getElementById("reset-week-btn")?.addEventListener("click", () => {
    weekOffset = 0;
    renderPlanner();
  });
  document.getElementById("open-settings-from-planner")?.addEventListener("click", openProfileModal);
});

// Meal completion
function completeMeal(key) {
  const recipeId = plan[key];
  const recipe = recipeById(recipeId);
  if (!recipe) return;

  if (settings.deductionMode === "RESERVATION_COMPLETE") {
    // Deduct now
    recipe.ingredients.forEach(ing => {
      const name = normalName(ing.name);
      const needed = convertToBase(ing.amount, ing.unit);
      const item = pantry.find(p => normalName(p.name) === name);
      if (item) {
        const current = convertToBase(item.quantity, item.unit);
        if (current.unit === needed.unit) {
          item.quantity = Math.max(0, current.amount - needed.amount);
        }
      }
    });
  }

  if (!completed.includes(key)) {
    completed.push(key);
  }

  saveAllStorage();
  refreshEverything();
  showToast(`${recipe.name} marked complete! Bon appétit.`, "success");
}

// Assignment Modal
function openAssignModal(day = 0, slot = 0) {
  const recipeSelect = document.getElementById("assign-recipe");
  const daySelect = document.getElementById("assign-day");
  const slotSelect = document.getElementById("assign-slot");
  const modal = document.getElementById("assign-modal");

  if (!recipeSelect || !daySelect || !modal) return;

  recipeSelect.innerHTML = RECIPES.map(r => `
    <option value="${r.id}">${escapeHTML(r.name)} (${r.category})</option>
  `).join("");

  const weekDates = getWeekDates(weekOffset);
  daySelect.innerHTML = DAYS.map((name, i) => `
    <option value="${i}" ${i === day ? "selected" : ""}>
      ${name} (${weekDates[i].getDate()} ${weekDates[i].toLocaleDateString("en-IN", { month: "short" })})
    </option>
  `).join("");

  if (slotSelect) slotSelect.value = slot;

  modal.classList.add("open");
}

document.getElementById("confirm-assignment")?.addEventListener("click", () => {
  const recipeId = Number(document.getElementById("assign-recipe").value);
  const day = Number(document.getElementById("assign-day").value);
  const slot = Number(document.getElementById("assign-slot").value);

  assignRecipe(day, slot, recipeId);
  document.getElementById("assign-modal")?.classList.remove("open");
});

function assignRecipe(day, slot, recipeId) {
  const key = keyFor(day, slot);
  const recipe = recipeById(recipeId);
  if (!recipe) return;

  // If replacing existing meal, restore old stock first
  if (plan[key] && settings.deductionMode === "SRS_3_3_SCHEDULE") {
    restoreSRS33Stock(key);
  }

  plan[key] = recipeId;
  completed = completed.filter(k => k !== key);

  // Apply SRS 3.3 Stock Deduction immediately on scheduling
  if (settings.deductionMode === "SRS_3_3_SCHEDULE") {
    applySRS33ScheduleDeduction(recipe, key);
  }

  saveAllStorage();
  refreshEverything();

  showToast(`Scheduled ${recipe.name}. ${settings.deductionMode === "SRS_3_3_SCHEDULE" ? "Pantry stock deducted (SRS 3.3)." : "Stock reserved."}`, "success");
}

// Drag & drop support
let draggedRecipeId = null;
document.addEventListener("dragstart", e => {
  const card = e.target.closest("[data-recipe-card]");
  if (card) {
    draggedRecipeId = Number(card.dataset.recipeCard);
    e.dataTransfer.setData("text/plain", String(draggedRecipeId));
    e.dataTransfer.effectAllowed = "copy";
  }
});
document.addEventListener("dragover", e => {
  const slot = e.target.closest(".meal-slot");
  if (slot) {
    e.preventDefault();
    slot.classList.add("drag-over");
  }
});
document.addEventListener("dragleave", e => {
  const slot = e.target.closest(".meal-slot");
  if (slot) slot.classList.remove("drag-over");
});
document.addEventListener("drop", e => {
  const slot = e.target.closest(".meal-slot");
  if (!slot) return;
  e.preventDefault();
  slot.classList.remove("drag-over");

  const id = Number(e.dataTransfer.getData("text/plain")) || draggedRecipeId;
  if (!id) return;

  assignRecipe(Number(slot.dataset.day), Number(slot.dataset.slot), id);
  draggedRecipeId = null;
});

// --- 8. RECIPE CATALOG RENDERER ---
function renderRecipes() {
  const searchInput = document.getElementById("recipe-search");
  const filterSelect = document.getElementById("recipe-filter");
  const readyToggle = document.getElementById("filter-pantry-ready");
  const grid = document.getElementById("recipe-grid");
  if (!grid) return;

  const search = normalName(searchInput?.value || "");
  const category = filterSelect?.value || "all";
  const readyOnly = readyToggle?.checked || false;

  const availability = getPantryAvailability();

  const filtered = RECIPES.filter(recipe => {
    const matchesSearch = normalName(recipe.name).includes(search) ||
      recipe.ingredients.some(i => normalName(i.name).includes(search));
    const matchesCategory = (category === "all" || recipe.category === category);

    if (!matchesSearch || !matchesCategory) return false;

    if (readyOnly) {
      // Check if 100% of ingredients are available in pantry
      const canMake = recipe.ingredients.every(ing => {
        const name = normalName(ing.name);
        const needed = convertToBase(ing.amount, ing.unit);
        const inStock = availability[name];
        return inStock && inStock.unit === needed.unit && inStock.available >= needed.amount;
      });
      if (!canMake) return false;
    }

    return true;
  });

  grid.innerHTML = filtered.map(recipe => {
    // Calculate ingredient coverage percentage
    let coveredCount = 0;
    recipe.ingredients.forEach(ing => {
      const name = normalName(ing.name);
      const needed = convertToBase(ing.amount, ing.unit);
      const inStock = availability[name];
      if (inStock && inStock.unit === needed.unit && inStock.available >= needed.amount) {
        coveredCount++;
      }
    });

    const isFullyCovered = coveredCount === recipe.ingredients.length;
    const coverageLabel = isFullyCovered
      ? "⚡ Ready to cook"
      : `${coveredCount}/${recipe.ingredients.length} ingredients`;

    return `
      <article class="recipe-card"
               draggable="true"
               data-recipe-card="${recipe.id}"
               data-open-recipe="${recipe.id}">
        <img src="${recipe.image}" alt="${escapeHTML(recipe.name)}">
        <div class="recipe-card-info">
          <div class="recipe-card-header">
            <small>${recipe.category.toUpperCase()}</small>
            <span class="coverage-tag ${isFullyCovered ? "full" : ""}">${coverageLabel}</span>
          </div>

          <h3>${escapeHTML(recipe.name)}</h3>
          <p>${escapeHTML(recipe.description)}</p>

          <div class="recipe-meta">
            <span>◷ ${recipe.time} MIN</span>
            <span>${recipe.calories || 350} KCAL</span>
            <span>₹${recipe.price}</span>
          </div>
        </div>
      </article>
    `;
  }).join("") || `<p class="empty-note">No recipes match your criteria.</p>`;
}

document.getElementById("recipe-search")?.addEventListener("input", renderRecipes);
document.getElementById("recipe-filter")?.addEventListener("change", renderRecipes);
document.getElementById("filter-pantry-ready")?.addEventListener("change", renderRecipes);
document.getElementById("recipe-grid")?.addEventListener("click", e => {
  const card = e.target.closest("[data-open-recipe]");
  if (card) openRecipe(Number(card.dataset.openRecipe));
});

// Recipe Modal Details
function openRecipe(id) {
  activeRecipe = recipeById(id);
  if (!activeRecipe) return;

  servingCount = activeRecipe.servings;
  renderRecipeDetails();
  document.getElementById("recipe-modal")?.classList.add("open");
}

function renderRecipeDetails() {
  const container = document.getElementById("recipe-details");
  if (!container || !activeRecipe) return;

  const recipe = activeRecipe;
  const availability = getPantryAvailability();

  const ingredientsHTML = recipe.ingredients.map(ing => {
    const scaledAmount = (ing.amount * servingCount) / recipe.servings;
    const needed = convertToBase(scaledAmount, ing.unit);
    const inStock = availability[normalName(ing.name)];

    const availableAmount = (inStock && inStock.unit === needed.unit) ? inStock.available : 0;
    const missing = Math.max(0, needed.amount - availableAmount);

    return `
      <div class="ingredient-row">
        <span>${escapeHTML(ing.name)}</span>
        <small>
          ${formatQuantity(scaledAmount, ing.unit)}
          ${missing > 0 ? `<span style="color:#8EB69B"> · Need ${formatQuantity(missing, ing.unit)}</span>` : " · In pantry ✓"}
        </small>
      </div>
    `;
  }).join("");

  const scaledPrice = Math.round((recipe.price * servingCount) / recipe.servings);
  const scaledCalories = Math.round((recipe.calories * servingCount) / recipe.servings);

  container.innerHTML = `
    <div class="recipe-detail-layout">
      <img class="recipe-detail-image" src="${recipe.image}" alt="${escapeHTML(recipe.name)}">
      <div class="recipe-detail-content">
        <span class="eyebrow">${recipe.category.toUpperCase()} · WEEKWOK KITCHEN</span>
        <h2>${escapeHTML(recipe.name)}</h2>
        <p>${escapeHTML(recipe.description)}</p>

        <div class="detail-meta">
          <span>◷ ${recipe.time} min</span>
          <span>₹${scaledPrice} approx</span>
          <span>⚡ ${scaledCalories} kcal</span>
        </div>

        <div class="serving-row">
          <span>Servings:</span>
          <button id="serving-minus">−</button>
          <strong>${servingCount}</strong>
          <button id="serving-plus">+</button>
        </div>

        <h3>Ingredients</h3>
        ${ingredientsHTML}

        <h3 style="margin-top: 18px;">Preparation Method</h3>
        <ol class="instructions">
          ${recipe.instructions.map(step => `<li>${escapeHTML(step)}</li>`).join("")}
        </ol>

        <div class="recipe-detail-actions">
          <button class="primary-btn" id="recipe-add-plan">
            Add to meal plan ↗
          </button>
          <button class="outline-btn" id="recipe-close">
            Close
          </button>
        </div>
      </div>
    </div>
  `;

  document.getElementById("serving-minus")?.addEventListener("click", () => {
    if (servingCount > 1) {
      servingCount--;
      renderRecipeDetails();
    }
  });
  document.getElementById("serving-plus")?.addEventListener("click", () => {
    if (servingCount < 20) {
      servingCount++;
      renderRecipeDetails();
    }
  });
  document.getElementById("recipe-add-plan")?.addEventListener("click", () => {
    document.getElementById("recipe-modal")?.classList.remove("open");
    openAssignModal();
    const select = document.getElementById("assign-recipe");
    if (select) select.value = recipe.id;
  });
  document.getElementById("recipe-close")?.addEventListener("click", () => {
    document.getElementById("recipe-modal")?.classList.remove("open");
  });
}

// --- 9. PANTRY MANAGER RENDERER ---
function renderPantry() {
  const summaryEl = document.getElementById("pantry-summary");
  const bodyEl = document.getElementById("pantry-body");
  const alertsEl = document.getElementById("pantry-alerts");
  if (!bodyEl) return;

  const availability = getPantryAvailability();
  const total = pantry.length;

  const lowStockCount = pantry.filter(item => {
    const data = availability[normalName(item.name)];
    return data && data.available < 100 && item.unit !== "pcs";
  }).length;

  const expiringItems = getExpiringItems();

  if (summaryEl) {
    summaryEl.innerHTML = `
      <div><strong>${total}</strong><small>Ingredients tracked</small></div>
      <div><strong>${lowStockCount}</strong><small>Low-stock items</small></div>
      <div><strong>${expiringItems.length}</strong><small>Expiring soon (&le;3 days)</small></div>
    `;
  }

  bodyEl.innerHTML = pantry.map(item => {
    const data = availability[normalName(item.name)] || { reserved: 0, available: item.quantity };
    const base = convertToBase(item.quantity, item.unit);

    let daysLeft = null;
    if (item.expiry) {
      const expDate = new Date(item.expiry + "T00:00:00");
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      daysLeft = Math.ceil((expDate - today) / 86400000);
    }

    let status = "In stock";
    let statusClass = "in-stock";

    if (daysLeft !== null && daysLeft < 0) {
      status = "Expired";
      statusClass = "expiring";
    } else if (daysLeft !== null && daysLeft <= 3) {
      status = "Expiring soon";
      statusClass = "expiring";
    } else if (data.available <= 0) {
      status = "Fully reserved";
      statusClass = "low";
    } else if (data.available < 100 && base.unit !== "pcs") {
      status = "Low stock";
      statusClass = "low";
    }

    return `
      <tr>
        <td><strong>${escapeHTML(item.name)}</strong></td>
        <td>${formatQuantity(base.amount, base.unit)}</td>
        <td>${formatQuantity(data.reserved, base.unit)}</td>
        <td>${formatQuantity(data.available, base.unit)}</td>
        <td>${item.expiry || "—"}</td>
        <td><span class="status-badge ${statusClass}">${status}</span></td>
        <td>
          <button class="table-action" data-delete-pantry="${item.id}">Remove</button>
        </td>
      </tr>
    `;
  }).join("") || `<tr><td colspan="7" style="text-align:center; padding:20px;">No pantry items yet. Click "+ Add ingredient" to start.</td></tr>`;

  // Expiry alerts
  if (alertsEl) {
    const alerts = [];
    pantry.forEach(item => {
      if (!item.expiry) return;
      const expDate = new Date(item.expiry + "T00:00:00");
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const diff = Math.ceil((expDate - today) / 86400000);

      if (diff >= 0 && diff <= 3) {
        alerts.push(`
          <div class="alert-box warning">
            ⚠ <strong>${escapeHTML(item.name)}</strong> expires ${diff === 0 ? "today" : `in ${diff} day(s)`}. Consider scheduling a recipe using this item.
          </div>
        `);
      } else if (diff < 0) {
        alerts.push(`
          <div class="alert-box warning">
            ⚠ <strong>${escapeHTML(item.name)}</strong> has expired. Please verify before cooking.
          </div>
        `);
      }
    });

    alertsEl.innerHTML = alerts.join("") || `<div class="alert-box">✳ Your kitchen pantry has no urgent expiry alerts.</div>`;
  }
}

function getExpiringItems() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  return pantry.filter(item => {
    if (!item.expiry) return false;
    const expDate = new Date(item.expiry + "T00:00:00");
    const diff = Math.ceil((expDate - today) / 86400000);
    return diff >= 0 && diff <= 3;
  });
}

// Pantry Form Submit
document.getElementById("open-pantry-form")?.addEventListener("click", () => {
  document.getElementById("pantry-modal")?.classList.add("open");
});

document.getElementById("pantry-form")?.addEventListener("submit", e => {
  e.preventDefault();
  const name = document.getElementById("ingredient-name").value.trim();
  const quantity = Number(document.getElementById("ingredient-quantity").value);
  const unit = document.getElementById("ingredient-unit").value;
  const expiry = document.getElementById("ingredient-expiry").value;
  const price = Number(document.getElementById("ingredient-price").value) || 0.15;

  if (!name || quantity <= 0) {
    showToast("Please enter a valid ingredient name and quantity.", "warning");
    return;
  }

  const base = convertToBase(quantity, unit);
  const existing = pantry.find(p => normalName(p.name) === normalName(name));

  if (existing) {
    const existingBase = convertToBase(existing.quantity, existing.unit);
    if (existingBase.unit !== base.unit) {
      showToast("Unit mismatch: existing item uses a different unit type.", "error");
      return;
    }
    existing.quantity = existingBase.amount + base.amount;
    existing.unit = base.unit;
    if (expiry) existing.expiry = expiry;
    if (price > 0) existing.price = price;
  } else {
    pantry.push({
      id: Date.now(),
      name,
      quantity: base.amount,
      unit: base.unit,
      expiry: expiry || null,
      price
    });
  }

  saveAllStorage();
  e.target.reset();
  document.getElementById("pantry-modal")?.classList.remove("open");
  refreshEverything();
  showToast(`${name} saved to pantry.`, "success");
});

document.getElementById("pantry-body")?.addEventListener("click", e => {
  const btn = e.target.closest("[data-delete-pantry]");
  if (!btn) return;

  const id = Number(btn.dataset.deletePantry);
  const item = pantry.find(p => p.id === id);
  if (!item) return;

  if (confirm(`Remove ${item.name} from pantry?`)) {
    pantry = pantry.filter(p => p.id !== id);
    saveAllStorage();
    refreshEverything();
    showToast("Ingredient removed.", "info");
  }
});

// --- 10. SHOPPING LIST RENDERER ---
function renderShopping() {
  const items = getShoppingItems();
  const listEl = document.getElementById("shopping-list");
  if (!listEl) return;

  const categories = {
    "Fresh Produce": ["tomato", "onion", "spinach", "potato", "cucumber", "carrot", "lemon", "avocado", "basil", "garlic"],
    "Dairy & Protein": ["paneer", "milk", "cream", "egg", "yoghurt", "butter"],
    "Pantry Staples": ["rice", "pasta", "oat", "flour", "oil", "honey", "chickpea", "bread", "coconut"],
    "Other Essentials": []
  };

  const grouped = {};
  items.forEach(item => {
    let cat = "Other Essentials";
    for (const [groupName, keywords] of Object.entries(categories)) {
      if (groupName === "Other Essentials") continue;
      if (keywords.some(k => normalName(item.name).includes(k))) {
        cat = groupName;
        break;
      }
    }
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(item);
  });

  listEl.innerHTML = Object.entries(grouped).map(([category, entries]) => `
    <section class="shopping-category">
      <h3>${category}</h3>
      <small>WEEKLY GAP REQUIREMENTS</small>

      ${entries.map(item => {
        const key = normalName(item.name);
        const isChecked = checkedShopping.includes(key);

        return `
          <div class="shopping-item ${isChecked ? "checked" : ""}">
            <label>
              <input type="checkbox"
                     data-shopping="${escapeHTML(key)}"
                     ${isChecked ? "checked" : ""}>
              <span>${escapeHTML(item.name)}</span>
            </label>
            <small>${formatQuantity(item.amount, item.unit)}</small>
          </div>
        `;
      }).join("")}
    </section>
  `).join("") || `
    <div class="shopping-category" style="grid-column: 1 / -1; text-align: center; padding: 40px;">
      <h3>Pantry is completely stocked!</h3>
      <p style="color:var(--sage); margin-top:8px;">All scheduled meals are 100% covered by current pantry inventory.</p>
    </div>
  `;

  // Totals & progress
  const doneCount = items.filter(i => checkedShopping.includes(normalName(i.name))).length;
  const estimatedCost = items.reduce((sum, i) => sum + (i.amount * (i.price || 0.15)), 0);

  document.getElementById("shopping-cost").textContent = `₹${Math.round(estimatedCost)}`;
  document.getElementById("shopping-count").textContent = `${doneCount} / ${items.length}`;

  const pct = items.length > 0 ? (doneCount / items.length) * 100 : 0;
  document.getElementById("shopping-progress-bar").style.width = `${pct}%`;

  const msgEl = document.getElementById("shopping-message");
  if (msgEl) {
    msgEl.textContent = items.length === 0
      ? "No grocery gaps detected."
      : `${items.length - doneCount} ingredients remaining to purchase.`;
  }

  // Sidebar badge
  const badge = document.getElementById("sidebar-shopping-badge");
  if (badge) {
    if (items.length > 0) {
      badge.textContent = items.length;
      badge.style.display = "inline-block";
    } else {
      badge.style.display = "none";
    }
  }
}

document.getElementById("shopping-list")?.addEventListener("change", e => {
  const checkbox = e.target;
  if (!checkbox.matches("[data-shopping]")) return;

  const key = checkbox.dataset.shopping;
  if (checkbox.checked) {
    if (!checkedShopping.includes(key)) checkedShopping.push(key);
  } else {
    checkedShopping = checkedShopping.filter(k => k !== key);
  }

  saveAllStorage();
  renderShopping();
});

document.getElementById("clear-checked-btn")?.addEventListener("click", () => {
  checkedShopping = [];
  saveAllStorage();
  renderShopping();
  showToast("Cleared collected items.", "info");
});

document.getElementById("print-shopping-btn")?.addEventListener("click", () => {
  window.print();
});

document.getElementById("whatsapp-btn")?.addEventListener("click", () => {
  const items = getShoppingItems();
  if (items.length === 0) {
    showToast("Shopping list is currently empty.", "warning");
    return;
  }

  let text = `🛒 *WEEKWOK SHOPPING LIST*\n`;
  text += `_Generated on ${new Date().toLocaleDateString("en-IN")}_\n\n`;

  items.forEach(item => {
    const isDone = checkedShopping.includes(normalName(item.name));
    text += `${isDone ? "✅" : "☐"} *${item.name}*: ${formatQuantity(item.amount, item.unit)}\n`;
  });

  text += `\n🌿 Prepared with WeekWok Smart Meal Planner.`;
  const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
  window.open(url, "_blank");
});

// --- 11. ANALYTICS & MACROS RENDERER ---
function renderAnalytics() {
  let totalCalories = 0;
  let totalProtein = 0;
  let totalCarbs = 0;
  let totalFat = 0;
  let totalCost = 0;

  Object.values(plan).forEach(recipeId => {
    const r = recipeById(recipeId);
    if (r) {
      totalCalories += (r.calories || 350);
      totalProtein += (r.protein || 15);
      totalCarbs += (r.carbs || 40);
      totalFat += (r.fat || 12);
      totalCost += (r.price || 120);
    }
  });

  const dailyCal = Math.round(totalCalories / 7);

  document.getElementById("analytics-total-cal").textContent = `${totalCalories.toLocaleString()} kcal`;
  document.getElementById("analytics-daily-cal").textContent = `${dailyCal} kcal`;

  document.getElementById("macro-protein").textContent = `${totalProtein}g`;
  document.getElementById("macro-carbs").textContent = `${totalCarbs}g`;
  document.getElementById("macro-fats").textContent = `${totalFat}g`;

  // Macro progress tracks
  const totalMacroGrams = Math.max(1, totalProtein + totalCarbs + totalFat);
  document.getElementById("bar-protein").style.width = `${Math.round((totalProtein / totalMacroGrams) * 100)}%`;
  document.getElementById("bar-carbs").style.width = `${Math.round((totalCarbs / totalMacroGrams) * 100)}%`;
  document.getElementById("bar-fats").style.width = `${Math.round((totalFat / totalMacroGrams) * 100)}%`;

  // Budget
  const targetBudget = Number(settings.weeklyBudget) || 2500;
  document.getElementById("analytics-budget-spent").textContent = `₹${totalCost.toLocaleString()}`;
  document.getElementById("analytics-budget-target").textContent = `₹${targetBudget.toLocaleString()}`;

  const budgetPct = Math.min(100, Math.round((totalCost / targetBudget) * 100));
  document.getElementById("budget-progress-bar").style.width = `${budgetPct}%`;

  const remaining = targetBudget - totalCost;
  document.getElementById("budget-remaining-text").textContent = remaining >= 0
    ? `Remaining: ₹${remaining.toLocaleString()}`
    : `Over budget: ₹${Math.abs(remaining).toLocaleString()}`;

  const statusPill = document.getElementById("budget-status-pill");
  if (statusPill) {
    statusPill.textContent = remaining >= 0 ? "Within Budget" : "Exceeded";
    statusPill.style.color = remaining >= 0 ? "var(--mint)" : "#8EB69B";
  }

  // Waste prevention & efficiency
  const expiringCount = getExpiringItems().length;
  const utilization = pantry.length > 0 ? Math.round(((pantry.length - expiringCount) / pantry.length) * 100) : 100;

  document.getElementById("analytics-pantry-score").textContent = `${utilization}%`;
  document.getElementById("metric-tracked").textContent = pantry.length;
  document.getElementById("metric-expiring").textContent = expiringCount;
  document.getElementById("metric-savings").textContent = `₹${Math.round(totalCost * 0.22)}`;
}

document.getElementById("export-summary-btn")?.addEventListener("click", () => {
  const report = {
    generatedAt: new Date().toISOString(),
    kitchen: settings.kitchenName,
    chef: settings.chefName,
    deductionEngine: settings.deductionMode,
    mealsPlannedCount: Object.keys(plan).length,
    pantryItemCount: pantry.length,
    shoppingGapsCount: getShoppingItems().length
  };

  const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `WeekWok_Kitchen_Report_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  showToast("Kitchen report exported.", "success");
});

// --- 12. HOME DASHBOARD RENDERER ---
function renderHome() {
  const mealCount = Object.keys(plan).filter(k => plan[k]).length;
  document.getElementById("stat-meals").textContent = mealCount;
  document.getElementById("stat-pantry").textContent = pantry.length;
  document.getElementById("stat-shopping").textContent = getShoppingItems().length;
  document.getElementById("stat-expiring").textContent = getExpiringItems().length;

  const container = document.getElementById("home-meals");
  if (!container) return;

  const plannedEntries = Object.entries(plan).filter(([k, id]) => id).slice(0, 4);

  if (plannedEntries.length === 0) {
    container.innerHTML = `
      <div class="home-meal-card" style="grid-column: 1 / -1; padding: 30px; text-align: center;">
        <small>YOUR TABLE IS EMPTY</small>
        <h3>No meals planned yet.</h3>
        <p>Click "Plan your week" or drag recipes to schedule your menu.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = plannedEntries.map(([key, id]) => {
    const recipe = recipeById(id);
    if (!recipe) return "";

    const [dayIndex, slotIndex] = key.split("-").map(Number);
    const dayName = DAYS[dayIndex] || "Day";
    const slotName = SLOTS[slotIndex] || "Meal";

    return `
      <article class="home-meal-card" data-home-recipe="${recipe.id}">
        <img src="${recipe.image}" alt="${escapeHTML(recipe.name)}">
        <div>
          <small>${dayName.toUpperCase()} · ${slotName.toUpperCase()}</small>
          <h3>${escapeHTML(recipe.name)}</h3>
          <p>◷ ${recipe.time} min · ${recipe.category}</p>
        </div>
      </article>
    `;
  }).join("");
}

document.getElementById("home-meals")?.addEventListener("click", e => {
  const card = e.target.closest("[data-home-recipe]");
  if (card) openRecipe(Number(card.dataset.homeRecipe));
});

// --- 13. PROFILE & SETTINGS MODAL ---
function openProfileModal() {
  const modal = document.getElementById("profile-modal");
  if (!modal) return;

  document.getElementById("settings-kitchen-name").value = settings.kitchenName || "My Kitchen";
  document.getElementById("settings-chef-name").value = settings.chefName || "Chef Jahnavi";
  document.getElementById("settings-deduction-mode").value = settings.deductionMode || "SRS_3_3_SCHEDULE";
  document.getElementById("settings-weekly-budget").value = settings.weeklyBudget || 2500;
  document.getElementById("settings-diet").value = settings.dietPreference || "All";

  modal.classList.add("open");
}

document.getElementById("sidebar-profile-btn")?.addEventListener("click", openProfileModal);

document.getElementById("profile-settings-form")?.addEventListener("submit", e => {
  e.preventDefault();
  settings.kitchenName = document.getElementById("settings-kitchen-name").value.trim() || "My Kitchen";
  settings.chefName = document.getElementById("settings-chef-name").value.trim() || "Chef";
  settings.deductionMode = document.getElementById("settings-deduction-mode").value;
  settings.weeklyBudget = Number(document.getElementById("settings-weekly-budget").value) || 2500;
  settings.dietPreference = document.getElementById("settings-diet").value;

  saveAllStorage();
  updateProfileDisplays();
  document.getElementById("profile-modal")?.classList.remove("open");
  refreshEverything();
  showToast("Kitchen settings saved successfully.", "success");
});

document.getElementById("reset-sample-data-btn")?.addEventListener("click", () => {
  if (confirm("Reset kitchen data to fresh default recipes and pantry?")) {
    pantry = structuredClone(DEFAULT_PANTRY);
    plan = {};
    completed = [];
    checkedShopping = [];
    stockLedger = {};
    settings = structuredClone(DEFAULT_SETTINGS);
    saveAllStorage();
    updateProfileDisplays();
    document.getElementById("profile-modal")?.classList.remove("open");
    refreshEverything();
    showToast("Kitchen workspace reset to initial state.", "info");
  }
});

function updateProfileDisplays() {
  const nameEl = document.getElementById("sidebar-kitchen-name");
  const avatarEl = document.getElementById("sidebar-avatar");
  const roleEl = document.getElementById("sidebar-role-text");
  const engineTextEl = document.getElementById("sidebar-engine-text");

  if (nameEl) nameEl.textContent = settings.kitchenName || "My Kitchen";
  if (avatarEl) avatarEl.textContent = (settings.chefName || "J").charAt(0).toUpperCase();
  if (roleEl) roleEl.textContent = `${settings.chefName || "Chef"} · Settings ⚙`;
  if (engineTextEl) {
    engineTextEl.textContent = settings.deductionMode === "SRS_3_3_SCHEDULE"
      ? "SRS 3.3 Engine Active"
      : "Reservation Engine";
  }
}

// --- 14. NAVIGATION & MASTER REFRESH ---
function showPage(pageId) {
  document.querySelectorAll(".page").forEach(p => p.classList.toggle("active", p.id === pageId));
  document.querySelectorAll(".nav-link").forEach(btn => btn.classList.toggle("active", btn.dataset.page === pageId));

  history.replaceState(null, "", `#${pageId}`);

  if (pageId === "home") renderHome();
  if (pageId === "planner") renderPlanner();
  if (pageId === "recipes") renderRecipes();
  if (pageId === "pantry") renderPantry();
  if (pageId === "shopping") renderShopping();
  if (pageId === "analytics") renderAnalytics();
}

document.querySelectorAll("[data-page]").forEach(btn => {
  btn.addEventListener("click", () => showPage(btn.dataset.page));
});
document.querySelectorAll("[data-go]").forEach(btn => {
  btn.addEventListener("click", () => showPage(btn.dataset.go));
});

function refreshEverything() {
  saveAllStorage();
  renderHome();
  renderPlanner();
  renderRecipes();
  renderPantry();
  renderShopping();
  renderAnalytics();
}

// Modal closing helpers
document.querySelectorAll("[data-close]").forEach(btn => {
  btn.addEventListener("click", () => {
    btn.closest(".modal-overlay")?.classList.remove("open");
  });
});
document.querySelectorAll(".modal-overlay").forEach(overlay => {
  overlay.addEventListener("click", e => {
    if (e.target === overlay) overlay.classList.remove("open");
  });
});
document.addEventListener("keydown", e => {
  if (e.key === "Escape") {
    document.querySelectorAll(".modal-overlay").forEach(m => m.classList.remove("open"));
  }
});

// --- 15. DUAL-MODE BACKEND SYNC PROBE ---
async function probeBackend() {
  const pill = document.getElementById("backend-status-pill");
  const text = document.getElementById("backend-status-text");

  try {
    const res = await fetch("http://localhost:4000/api/health", { method: "GET" });
    if (res.ok) {
      backendOnline = true;
      if (text) text.textContent = "SQLite 3-Tier Connected";
      if (pill) pill.style.borderColor = "var(--sage)";
      return;
    }
  } catch (e) {
    // Backend offline, running standalone
  }

  backendOnline = false;
  if (text) text.textContent = "Standalone Mode (Storage Active)";
}

// --- 16. APPLICATION INITIALIZATION ---
document.addEventListener("DOMContentLoaded", () => {
  const dateEl = document.getElementById("current-date");
  if (dateEl) {
    dateEl.textContent = new Date().toLocaleDateString("en-IN", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric"
    });
  }

  updateProfileDisplays();
  probeBackend();
  refreshEverything();

  const hash = location.hash.replace("#", "");
  if (["home", "planner", "recipes", "pantry", "shopping", "analytics"].includes(hash)) {
    showPage(hash);
  }
});
