# 📋 Software Requirements Specification 3.3 (SRS 3.3)
## Pantry Stock Deduction Engine Specification

### 1. Purpose & Scope
This document formally defines the requirements, mathematical formulations, state machine, and algorithmic specifications for the **Pantry Stock Deduction Engine** in WeekWok, resolving the primary requirement deficiency identified in the previous academic project evaluation.

---

### 2. Operational Modes

#### 2.1 Mode A: SRS 3.3 Real-Time Schedule Deduction (Default)
In Mode A, inventory deduction is transactionally executed immediately upon assigning a recipe to a calendar slot:
$$\text{Stock}_{\text{new}} = \max(0, \text{Stock}_{\text{current}} - \text{Quantity}_{\text{required}})$$

- **Deduction Trigger**: Event `ASSIGN_MEAL(day, slot, recipeId, servings)`.
- **Restitution Trigger**: Event `REMOVE_MEAL(key)`. The exact deducted quantity is credited back into the pantry stock.
- **Audit Logging**: Every deduction and restitution logs a record in the `stock_transactions` table with timestamps.

#### 2.2 Mode B: Dual-Stage Reservation Engine
In Mode B, inventory is locked upon scheduling to prevent double-booking, and deducted permanently upon completion:
- Scheduling increments $\text{Quantity}_{\text{reserved}}$.
- Available stock is calculated as:
$$\text{Quantity}_{\text{available}} = \max(0, \text{Stock}_{\text{total}} - \text{Quantity}_{\text{reserved}})$$
- Marking a meal "Complete" decrements $\text{Stock}_{\text{total}}$ and clears the reservation.

---

### 3. Unit Conversion Normalization Formula
All calculations convert quantities into canonical base units:
- Solid Mass: $1\text{ kg} = 1000\text{ g}$
- Liquid Volume: $1\text{ L} = 1000\text{ ml}$
- Count: $\text{pcs}$ (invariable)

Incompatible conversions (e.g. attempting to add `g` to `ml` or `pcs`) are rejected with strict validation errors.

---

### 4. Verification & Automated Test Status
All criteria specified under SRS 3.3 are verified in the automated test suite located at `tests/pantryEngine.test.js`.
