import { Recipe, PantryItem, KitchenSettings } from '../types';

export const INITIAL_SETTINGS: KitchenSettings = {
  kitchenName: 'My Kitchen',
  chefName: 'Chef Jahnavi',
  deductionMode: 'SRS_3_3_SCHEDULE',
  weeklyBudget: 2500,
  dietPreference: 'All'
};

export const INITIAL_PANTRY: PantryItem[] = [
  { id: 1, name: 'Paneer', quantity: 400, unit: 'g', expiry: '2026-11-24', price: 0.35 },
  { id: 2, name: 'Basmati Rice', quantity: 1000, unit: 'g', expiry: '2027-04-10', price: 0.09 },
  { id: 3, name: 'Cooking Oil', quantity: 1000, unit: 'ml', expiry: '2027-02-15', price: 0.18 },
  { id: 4, name: 'Onions', quantity: 500, unit: 'g', expiry: '2026-11-28', price: 0.04 },
  { id: 5, name: 'Eggs', quantity: 6, unit: 'pcs', expiry: '2026-11-25', price: 7.0 },
  { id: 6, name: 'Tomatoes', quantity: 300, unit: 'g', expiry: '2026-11-23', price: 0.05 },
  { id: 7, name: 'Milk', quantity: 500, unit: 'ml', expiry: '2026-11-24', price: 0.06 },
  { id: 8, name: 'Potatoes', quantity: 500, unit: 'g', expiry: '2026-12-05', price: 0.03 }
];

export const RECIPES_DATA: Recipe[] = [
  {
    id: 1,
    name: 'Paneer Butter Masala',
    category: 'Dinner',
    time: 35,
    servings: 2,
    price: 180,
    calories: 480,
    protein: 22,
    carbs: 24,
    fat: 34,
    image: 'https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800',
    description: 'A rich, creamy paneer curry with tomatoes and aromatic spices.',
    ingredients: [
      { name: 'Paneer', amount: 400, unit: 'g' },
      { name: 'Butter', amount: 50, unit: 'g' },
      { name: 'Tomatoes', amount: 250, unit: 'g' },
      { name: 'Cream', amount: 100, unit: 'ml' },
      { name: 'Onions', amount: 100, unit: 'g' },
      { name: 'Cooking Oil', amount: 15, unit: 'ml' }
    ],
    instructions: [
      'Heat butter and oil in a pan.',
      'Add chopped onions and cook until soft.',
      'Add tomatoes and spices. Cook until smooth.',
      'Add paneer cubes and cream.',
      'Simmer for 8–10 minutes and serve warm.'
    ]
  },
  {
    id: 2,
    name: 'Garden Harvest Bowl',
    category: 'Lunch',
    time: 25,
    servings: 2,
    price: 120,
    calories: 290,
    protein: 10,
    carbs: 38,
    fat: 12,
    image: 'harvestgardenbowl.jpg',
    description: 'A refreshing bowl filled with seasonal vegetables and greens.',
    ingredients: [
      { name: 'Tomatoes', amount: 150, unit: 'g' },
      { name: 'Cucumber', amount: 150, unit: 'g' },
      { name: 'Spinach', amount: 100, unit: 'g' },
      { name: 'Olive Oil', amount: 15, unit: 'ml' },
      { name: 'Lemons', amount: 1, unit: 'pcs' }
    ],
    instructions: [
      'Wash and prepare all vegetables.',
      'Chop cucumber and tomatoes.',
      'Combine with fresh spinach.',
      'Dress with lemon and olive oil.',
      'Toss and serve chilled.'
    ]
  },
  {
    id: 3,
    name: 'Berry & Oat Bowl',
    category: 'Breakfast',
    time: 10,
    servings: 2,
    price: 90,
    calories: 340,
    protein: 16,
    carbs: 58,
    fat: 6,
    image: 'berry&oatmeal.jpg',
    description: 'A nourishing breakfast with rolled oats, fresh berries and creamy yoghurt.',
    ingredients: [
      { name: 'Rolled Oats', amount: 100, unit: 'g' },
      { name: 'Milk', amount: 250, unit: 'ml' },
      { name: 'Mixed Berries', amount: 100, unit: 'g' },
      { name: 'Honey', amount: 20, unit: 'g' },
      { name: 'Greek Yoghurt', amount: 100, unit: 'g' }
    ],
    instructions: [
      'Simmer oats in warm milk.',
      'Allow oats to cool slightly.',
      'Fold in yoghurt and top with berries.',
      'Drizzle with honey and serve.'
    ]
  },
  {
    id: 4,
    name: 'Avocado Sourdough',
    category: 'Breakfast',
    time: 12,
    servings: 2,
    price: 110,
    calories: 380,
    protein: 11,
    carbs: 42,
    fat: 20,
    image: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800',
    description: 'Crispy sourdough toast topped with seasoned ripe avocado.',
    ingredients: [
      { name: 'Bread', amount: 2, unit: 'pcs' },
      { name: 'Avocado', amount: 150, unit: 'g' },
      { name: 'Lemons', amount: 1, unit: 'pcs' },
      { name: 'Olive Oil', amount: 10, unit: 'ml' }
    ],
    instructions: [
      'Toast sourdough slices.',
      'Mash avocado with lemon juice and salt.',
      'Spread over toast and finish with olive oil.'
    ]
  },
  {
    id: 5,
    name: 'Tomato Basil Pasta',
    category: 'Dinner',
    time: 25,
    servings: 2,
    price: 140,
    calories: 440,
    protein: 14,
    carbs: 72,
    fat: 10,
    image: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800',
    description: 'Classic pasta tossed in a rich slow-simmered tomato and fresh sweet basil sauce.',
    ingredients: [
      { name: 'Pasta', amount: 200, unit: 'g' },
      { name: 'Tomatoes', amount: 300, unit: 'g' },
      { name: 'Olive Oil', amount: 20, unit: 'ml' },
      { name: 'Garlic', amount: 15, unit: 'g' },
      { name: 'Fresh Basil', amount: 15, unit: 'g' }
    ],
    instructions: [
      'Boil pasta al dente.',
      'Sauté minced garlic in olive oil.',
      'Add crushed tomatoes and simmer.',
      'Toss pasta and garnish with fresh basil.'
    ]
  },
  {
    id: 6,
    name: 'Golden Vegetable Curry',
    category: 'Dinner',
    time: 30,
    servings: 2,
    price: 130,
    calories: 360,
    protein: 9,
    carbs: 32,
    fat: 22,
    image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=800',
    description: 'Fragrant turmeric coconut curry with garden vegetables.',
    ingredients: [
      { name: 'Cooking Oil', amount: 20, unit: 'ml' },
      { name: 'Onions', amount: 100, unit: 'g' },
      { name: 'Potatoes', amount: 150, unit: 'g' },
      { name: 'Carrots', amount: 100, unit: 'g' },
      { name: 'Coconut Milk', amount: 200, unit: 'ml' }
    ],
    instructions: [
      'Sauté onions in hot oil.',
      'Add potatoes, carrots and spices.',
      'Pour coconut milk and simmer.',
      'Garnish with cilantro and serve.'
    ]
  },
  {
    id: 11,
    name: 'Crispy Herb Paneer Bites',
    category: 'Snacks',
    time: 15,
    servings: 2,
    price: 115,
    calories: 310,
    protein: 19,
    carbs: 8,
    fat: 23,
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800',
    description: 'Pan-seared spiced paneer cubes tossed in mint and herbs.',
    ingredients: [
      { name: 'Paneer', amount: 200, unit: 'g' },
      { name: 'Olive Oil', amount: 15, unit: 'ml' },
      { name: 'Lemons', amount: 1, unit: 'pcs' },
      { name: 'Fresh Basil', amount: 10, unit: 'g' }
    ],
    instructions: [
      'Cube fresh paneer.',
      'Toss with olive oil, salt, and spices.',
      'Sear until golden brown.',
      'Serve with lemon wedge.'
    ]
  }
];
