import React from 'react';
import { useKitchen } from '../context/KitchenContext';

export const AnalyticsView: React.FC = () => {
  const { plan, recipes, settings, pantry } = useKitchen();

  let totalCalories = 0;
  let totalProtein = 0;
  let totalCarbs = 0;
  let totalFat = 0;
  let totalCost = 0;

  Object.values(plan).forEach(rId => {
    const r = recipes.find(x => x.id === rId);
    if (r) {
      totalCalories += r.calories;
      totalProtein += r.protein;
      totalCarbs += r.carbs;
      totalFat += r.fat;
      totalCost += r.price;
    }
  });

  const dailyCal = Math.round(totalCalories / 7);
  const totalMacros = Math.max(1, totalProtein + totalCarbs + totalFat);
  const targetBudget = settings.weeklyBudget || 2500;
  const budgetPct = Math.min(100, Math.round((totalCost / targetBudget) * 100));
  const remaining = targetBudget - totalCost;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiringSoon = pantry.filter(item => {
    if (!item.expiry) return false;
    const diff = Math.ceil((new Date(item.expiry + 'T00:00:00').getTime() - today.getTime()) / 86400000);
    return diff >= 0 && diff <= 3;
  }).length;

  const utilization = pantry.length > 0
    ? Math.round(((pantry.length - expiringSoon) / pantry.length) * 100)
    : 100;

  return (
    <div className="page active">
      <div className="page-heading">
        <div>
          <span className="eyebrow">KITCHEN INTELLIGENCE</span>
          <h1>Nutrition &amp; <em>Budget.</em></h1>
          <p>Track macronutrients, estimated grocery budget adherence, and pantry waste prevention.</p>
        </div>
      </div>

      <div className="analytics-grid">
        <div className="analytics-card">
          <span className="eyebrow">WEEKLY MACRONUTRIENT TOTALS</span>
          <h3>{totalCalories.toLocaleString()} kcal</h3>
          <p className="analytics-sub">Average per day: <strong>{dailyCal} kcal</strong></p>

          <div className="macro-bars">
            <div className="macro-item">
              <div className="macro-label">
                <span>Protein</span>
                <strong>{totalProtein}g</strong>
              </div>
              <div className="macro-track">
                <div className="macro-fill protein" style={{ width: `${(totalProtein / totalMacros) * 100}%` }}></div>
              </div>
            </div>

            <div className="macro-item">
              <div className="macro-label">
                <span>Carbohydrates</span>
                <strong>{totalCarbs}g</strong>
              </div>
              <div className="macro-track">
                <div className="macro-fill carbs" style={{ width: `${(totalCarbs / totalMacros) * 100}%` }}></div>
              </div>
            </div>

            <div className="macro-item">
              <div className="macro-label">
                <span>Healthy Fats</span>
                <strong>{totalFat}g</strong>
              </div>
              <div className="macro-track">
                <div className="macro-fill fats" style={{ width: `${(totalFat / totalMacros) * 100}%` }}></div>
              </div>
            </div>
          </div>
        </div>

        <div className="analytics-card">
          <span className="eyebrow">GROCERY BUDGET TRACKER</span>
          <h3>₹{totalCost.toLocaleString()}</h3>
          <p className="analytics-sub">Weekly Target: <strong>₹{targetBudget.toLocaleString()}</strong></p>

          <div className="budget-progress-box">
            <div className="progress-track">
              <div className="progress-fill" style={{ width: `${budgetPct}%` }}></div>
            </div>
            <div className="budget-detail-row">
              <span>{remaining >= 0 ? `Remaining: ₹${remaining.toLocaleString()}` : `Over: ₹${Math.abs(remaining).toLocaleString()}`}</span>
              <span className="badge">{remaining >= 0 ? 'Within Budget' : 'Exceeded'}</span>
            </div>
          </div>
        </div>

        <div className="analytics-card">
          <span className="eyebrow">PANTRY UTILIZATION</span>
          <h3>{utilization}%</h3>
          <p className="analytics-sub">Ingredients freshness &amp; usage efficiency</p>

          <ul className="waste-metrics-list">
            <li><span>Tracked pantry items:</span> <strong>{pantry.length}</strong></li>
            <li><span>Expiring within 72 hours:</span> <strong className="warning-text">{expiringSoon}</strong></li>
            <li><span>Estimated savings vs waste:</span> <strong className="sage-text">₹{Math.round(totalCost * 0.22)}</strong></li>
          </ul>
        </div>
      </div>
    </div>
  );
};
