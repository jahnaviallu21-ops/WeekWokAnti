import React from 'react';
import { useKitchen } from '../context/KitchenContext';

export const Toast: React.FC = () => {
  const { toastMessage } = useKitchen();
  if (!toastMessage) return null;

  return (
    <div className="toast show">
      ✓ {toastMessage}
    </div>
  );
};
