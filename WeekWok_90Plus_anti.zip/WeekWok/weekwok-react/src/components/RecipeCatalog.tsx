import React, { useState } from 'react';
import { useKitchen } from '../context/KitchenContext';
import { Recipe } from '../types';

interface RecipeCatalogProps {
  onOpenRecipe: (recipe: Recipe) => void;
}

export const RecipeCatalog: React.FC<RecipeCatalogProps> = ({ onOpenRecipe }) => {
  const { recipes, getPantryAvailability } = useKitchen();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const [readyOnly, setReadyOnly] = useState(false);

  const availability = getPantryAvailability();

  const filtered = recipes.filter(recipe => {
    const s = search.toLowerCase();
    const matchesSearch = recipe.name.toLowerCase().includes(s) ||
      recipe.ingredients.some(i => i.name.toLowerCase().includes(s));
    const matchesCat = (category === 'all' || recipe.category === category);

    if (!matchesSearch || !matchesCat) return false;

    if (readyOnly) {
      const canMake = recipe.ingredients.every(ing => {
        const item = availability[ing.name.toLowerCase()];
        return item && item.available >= ing.amount;
      });
      if (!canMake) return false;
    }

    return true;
  });

  return (
    <div className="page active">
      <div className="page-heading">
        <div>
          <span className="eyebrow">THE RECIPE COLLECTION</span>
          <h1>Made with <em>love.</em></h1>
          <p>Search, filter by category or dietary goals, and instantly check pantry ingredient coverage.</p>
        </div>

        <div className="pantry-coverage-filter">
          <label className="toggle-pill-label">
            <input
              type="checkbox"
              checked={readyOnly}
              onChange={(e) => setReadyOnly(e.target.checked)}
            />
            <span className="toggle-pill">⚡ Only recipes I can make now</span>
          </label>
        </div>
      </div>

      <div className="recipe-toolbar">
        <div className="search-input-wrap">
          <span className="search-icon">🔍</span>
          <input
            type="search"
            placeholder="Search recipes by name, ingredients or cuisine..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <select
          className="custom-select"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="all">All categories</option>
          <option value="Breakfast">Breakfast</option>
          <option value="Lunch">Lunch</option>
          <option value="Dinner">Dinner</option>
          <option value="Snacks">Snacks & Quick Bites</option>
        </select>
      </div>

      <div className="recipe-grid">
        {filtered.map(recipe => {
          let covered = 0;
          recipe.ingredients.forEach(i => {
            const avail = availability[i.name.toLowerCase()];
            if (avail && avail.available >= i.amount) covered++;
          });
          const full = covered === recipe.ingredients.length;

          return (
            <article
              key={recipe.id}
              className="recipe-card"
              onClick={() => onOpenRecipe(recipe)}
            >
              <img src={recipe.image} alt={recipe.name} />
              <div className="recipe-card-info">
                <div className="recipe-card-header">
                  <small>{recipe.category.toUpperCase()}</small>
                  <span className={`coverage-tag ${full ? 'full' : ''}`}>
                    {full ? '⚡ Ready to cook' : `${covered}/${recipe.ingredients.length} in stock`}
                  </span>
                </div>

                <h3>{recipe.name}</h3>
                <p>{recipe.description}</p>

                <div className="recipe-meta">
                  <span>◷ {recipe.time} MIN</span>
                  <span>{recipe.calories} KCAL</span>
                  <span>₹{recipe.price}</span>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
};
