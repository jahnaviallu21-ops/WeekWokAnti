import React, { useState } from 'react';
import { useKitchen } from '../context/KitchenContext';
import { Recipe } from '../types';

interface PlannerViewProps {
  onOpenRecipe: (recipe: Recipe) => void;
  onOpenSettings: () => void;
}

export const PlannerView: React.FC<PlannerViewProps> = ({ onOpenRecipe, onOpenSettings }) => {
  const { plan, completed, recipes, settings, weekOffset, setWeekOffset, removeMeal, completeMeal, assignMeal } = useKitchen();
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<{ day: number; slot: number } | null>(null);
  const [chosenRecipeId, setChosenRecipeId] = useState<number>(recipes[0]?.id || 1);

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const slots = ['Breakfast', 'Lunch', 'Dinner'];

  // Calculate dynamic week dates
  const now = new Date();
  const dayOfWeek = now.getDay();
  const distanceToMonday = (dayOfWeek + 6) % 7;
  const monday = new Date(now);
  monday.setDate(now.getDate() - distanceToMonday + (weekOffset * 7));
  monday.setHours(0, 0, 0, 0);

  const weekDates = days.map((_, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    return d;
  });

  const weekLabel = weekOffset === 0
    ? 'Current Week'
    : `${weekDates[0].toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })} – ${weekDates[6].toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}`;

  const handleOpenSlot = (day: number, slot: number) => {
    setSelectedSlot({ day, slot });
    setModalOpen(true);
  };

  const handleConfirmAssignment = () => {
    if (selectedSlot) {
      assignMeal(selectedSlot.day, selectedSlot.slot, chosenRecipeId);
      setModalOpen(false);
    }
  };

  return (
    <div className="page active">
      <div className="page-heading">
        <div>
          <span className="eyebrow">YOUR PERSONAL MENU</span>
          <h1>The weekly <em>table.</em></h1>
          <p>Arrange breakfast, lunch, and dinner. The SRS 3.3 engine automatically tracks ingredients and pantry reservations.</p>
        </div>

        <div className="heading-controls">
          <div className="week-navigation">
            <button className="nav-arrow-btn" onClick={() => setWeekOffset(w => w - 1)} title="Previous Week">‹</button>
            <span className="current-week-label">{weekLabel}</span>
            <button className="nav-arrow-btn" onClick={() => setWeekOffset(w => w + 1)} title="Next Week">›</button>
            <button className="secondary-btn-sm" onClick={() => setWeekOffset(0)}>Today</button>
          </div>
        </div>
      </div>

      <div className="planner-toolbar-row">
        <div className="planner-info">
          <span>✳ Click an empty slot to schedule.</span>
          <span>SRS 3.3 mode deducts ingredients in real time upon assignment.</span>
        </div>

        <div className="engine-mode-indicator">
          <span>Engine:</span>
          <strong>{settings.deductionMode === 'SRS_3_3_SCHEDULE' ? 'SRS 3.3 Schedule Deduction' : 'Reservation Mode'}</strong>
          <button className="text-link-btn" onClick={onOpenSettings}>Configure ⚙</button>
        </div>
      </div>

      <div className="planner-legend">
        <span><i className="breakfast-dot"></i> Breakfast</span>
        <span><i className="lunch-dot"></i> Lunch</span>
        <span><i className="dinner-dot"></i> Dinner</span>
        <span className="legend-note">✓ Green badge = stock reserved or deducted</span>
      </div>

      <div className="days-list">
        {days.map((dayName, dayIndex) => {
          const d = weekDates[dayIndex];
          const isToday = new Date().toDateString() === d.toDateString();

          return (
            <article key={dayIndex} className={`day-row ${isToday ? 'today-row' : ''}`}>
              <div className="day-date">
                <small>{dayName.toUpperCase()}</small>
                <strong>{d.getDate()}</strong>
                <span className="day-sub">{d.toLocaleDateString('en-IN', { month: 'short' })}</span>
              </div>

              {slots.map((slotName, slotIndex) => {
                const key = `${dayIndex}-${slotIndex}`;
                const recipeId = plan[key];
                const recipe = recipes.find(r => r.id === recipeId);
                const isCompleted = completed.includes(key);

                if (!recipe) {
                  return (
                    <div
                      key={slotIndex}
                      className="meal-slot empty"
                      onClick={() => handleOpenSlot(dayIndex, slotIndex)}
                    >
                      + Add {slotName}
                    </div>
                  );
                }

                return (
                  <div key={slotIndex} className="meal-slot">
                    <div className="meal-slot-header">
                      <small>{slotName.toUpperCase()}</small>
                      <span>◷ {recipe.time}m</span>
                    </div>

                    <strong>{recipe.name}</strong>

                    <span className={`meal-badge ${isCompleted ? 'completed' : 'deducted'}`}>
                      {isCompleted ? '✓ COMPLETED' : settings.deductionMode === 'SRS_3_3_SCHEDULE' ? '✓ DEDUCTED (SRS 3.3)' : '◈ RESERVED'}
                    </span>

                    <div className="slot-actions">
                      <button onClick={() => onOpenRecipe(recipe)}>Recipe</button>
                      <button onClick={() => removeMeal(key)}>Remove</button>
                      {!isCompleted && (
                        <button onClick={() => completeMeal(key)}>Complete</button>
                      )}
                    </div>
                  </div>
                );
              })}
            </article>
          );
        })}
      </div>

      {modalOpen && (
        <div className="modal-overlay open">
          <div className="modal small-modal">
            <button className="modal-close" onClick={() => setModalOpen(false)}>×</button>
            <span className="eyebrow">PLAN SOMETHING DELICIOUS</span>
            <h2>Add a <em>meal.</em></h2>

            <label>Choose a recipe</label>
            <select
              className="form-control"
              value={chosenRecipeId}
              onChange={(e) => setChosenRecipeId(Number(e.target.value))}
            >
              {recipes.map(r => (
                <option key={r.id} value={r.id}>{r.name} ({r.category})</option>
              ))}
            </select>

            <div className="modal-engine-notice">
              ℹ️ In <strong>SRS 3.3 Mode</strong>, pantry ingredients are automatically deducted upon scheduling.
            </div>

            <button className="primary-btn full-btn" onClick={handleConfirmAssignment}>
              Add to meal planner
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
