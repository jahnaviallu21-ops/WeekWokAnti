import React from 'react';

interface TopbarProps {
  onQuickCook: () => void;
}

export const Topbar: React.FC<TopbarProps> = ({ onQuickCook }) => {
  const currentDate = new Date().toLocaleDateString('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <header className="topbar">
      <div>
        <span className="top-eyebrow">YOUR KITCHEN, IN GOOD ORDER</span>
        <p>{currentDate}</p>
      </div>

      <div className="top-actions">
        <div className="system-status-pill">
          <span className="status-indicator"></span>
          <span>React + TS Dynamic Phase</span>
        </div>
        <button className="secondary-btn-sm" onClick={onQuickCook}>
          <span>⚡ What can I cook now?</span>
        </button>
      </div>
    </header>
  );
};
