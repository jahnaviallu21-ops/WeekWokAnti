import React from 'react';
import { useKitchen } from '../context/KitchenContext';

interface SidebarProps {
  activePage: string;
  setActivePage: (page: string) => void;
  onOpenProfile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activePage, setActivePage, onOpenProfile }) => {
  const { settings, getShoppingItems } = useKitchen();
  const shoppingCount = getShoppingItems().length;

  const pages = [
    { id: 'home', icon: '⌂', label: 'Home' },
    { id: 'planner', icon: '▦', label: 'Meal Planner' },
    { id: 'recipes', icon: '✳', label: 'Recipes' },
    { id: 'pantry', icon: '◈', label: 'My Pantry' },
    { id: 'shopping', icon: '🛒', label: 'Shopping List', count: shoppingCount },
    { id: 'analytics', icon: '📊', label: 'Analytics & Macros' },
  ];

  return (
    <aside className="sidebar">
      <a className="brand" onClick={() => setActivePage('home')}>
        <span className="brand-icon">w.</span>
        <span>
          weekwok
          <small>THE ART OF PLANNING WELL</small>
        </span>
      </a>

      <div className="sidebar-label">WORKSPACE</div>

      <nav className="navigation">
        {pages.map((p) => (
          <button
            key={p.id}
            className={`nav-link ${activePage === p.id ? 'active' : ''}`}
            onClick={() => setActivePage(p.id)}
          >
            <span className="nav-icon">{p.icon}</span>
            {p.label}
            {p.count ? <span className="badge">{p.count}</span> : null}
          </button>
        ))}
      </nav>

      <div className="sidebar-bottom">
        <div className="engine-badge-pill">
          <span className="pulse-dot"></span>
          <small>{settings.deductionMode === 'SRS_3_3_SCHEDULE' ? 'SRS 3.3 Active' : 'Reservation Mode'}</small>
        </div>

        <div className="sidebar-message">
          <span className="quote-sparkle">✳</span>
          <p>A little planning<br />goes a long way.</p>
          <small>MAKE EVERY MEAL COUNT.</small>
        </div>

        <div className="profile" onClick={onOpenProfile} title="Configure kitchen preferences">
          <div className="profile-avatar">{settings.chefName.charAt(0).toUpperCase()}</div>
          <div>
            <strong>{settings.kitchenName}</strong>
            <small>{settings.chefName} · Settings ⚙</small>
          </div>
        </div>
      </div>
    </aside>
  );
};
