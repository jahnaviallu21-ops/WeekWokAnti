import React, { useState } from 'react';
import { useKitchen } from '../context/KitchenContext';
import { UnitType } from '../types';

export const PantryView: React.FC = () => {
  const { pantry, addPantryItem, deletePantryItem, getPantryAvailability } = useKitchen();
  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState<UnitType>('g');
  const [expiry, setExpiry] = useState('');
  const [price, setPrice] = useState('');

  const availability = getPantryAvailability();

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !quantity) return;
    addPantryItem({
      name,
      quantity: Number(quantity),
      unit,
      expiry: expiry || null,
      price: price ? Number(price) : 0.15
    });
    setName('');
    setQuantity('');
    setExpiry('');
    setPrice('');
    setModalOpen(false);
  };

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const expiringCount = pantry.filter(item => {
    if (!item.expiry) return false;
    const diff = Math.ceil((new Date(item.expiry + 'T00:00:00').getTime() - today.getTime()) / 86400000);
    return diff >= 0 && diff <= 3;
  }).length;

  const lowStockCount = pantry.filter(item => {
    const data = availability[item.name.toLowerCase()];
    return data && data.available < 100 && item.unit !== 'pcs';
  }).length;

  return (
    <div className="page active">
      <div className="page-heading">
        <div>
          <span className="eyebrow">KNOW WHAT'S IN YOUR KITCHEN</span>
          <h1>My <em>pantry.</em></h1>
          <p>Track ingredients, units, quantities, real-time reservations, and expiry alerts.</p>
        </div>

        <button className="primary-btn" onClick={() => setModalOpen(true)}>
          + Add ingredient
        </button>
      </div>

      <div className="pantry-summary">
        <div><strong>{pantry.length}</strong><small>Ingredients tracked</small></div>
        <div><strong>{lowStockCount}</strong><small>Low-stock items</small></div>
        <div><strong>{expiringCount}</strong><small>Expiring soon (&le;3 days)</small></div>
      </div>

      <div className="pantry-table-wrapper">
        <table className="pantry-table">
          <thead>
            <tr>
              <th>INGREDIENT</th>
              <th>TOTAL STOCK</th>
              <th>RESERVED</th>
              <th>AVAILABLE</th>
              <th>EXPIRY DATE</th>
              <th>STATUS</th>
              <th>ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {pantry.map(item => {
              const data = availability[item.name.toLowerCase()] || { reserved: 0, available: item.quantity };
              let status = 'In stock';
              let sClass = 'in-stock';

              if (item.expiry) {
                const diff = Math.ceil((new Date(item.expiry + 'T00:00:00').getTime() - today.getTime()) / 86400000);
                if (diff < 0) {
                  status = 'Expired';
                  sClass = 'expiring';
                } else if (diff <= 3) {
                  status = 'Expiring soon';
                  sClass = 'expiring';
                }
              } else if (data.available <= 0) {
                status = 'Reserved';
                sClass = 'low';
              } else if (data.available < 100 && item.unit !== 'pcs') {
                status = 'Low stock';
                sClass = 'low';
              }

              return (
                <tr key={item.id}>
                  <td><strong>{item.name}</strong></td>
                  <td>{item.quantity} {item.unit}</td>
                  <td>{data.reserved} {item.unit}</td>
                  <td>{data.available} {item.unit}</td>
                  <td>{item.expiry || '—'}</td>
                  <td><span className={`status-badge ${sClass}`}>{status}</span></td>
                  <td>
                    <button className="table-action" onClick={() => deletePantryItem(item.id)}>Remove</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {modalOpen && (
        <div className="modal-overlay open">
          <div className="modal small-modal">
            <button className="modal-close" onClick={() => setModalOpen(false)}>×</button>
            <span className="eyebrow">YOUR KITCHEN INVENTORY</span>
            <h2>Add an <em>ingredient.</em></h2>

            <form onSubmit={handleAdd}>
              <label>Ingredient name</label>
              <input
                className="form-control"
                required
                placeholder="e.g. Paneer"
                value={name}
                onChange={e => setName(e.target.value)}
              />

              <label>Quantity</label>
              <input
                className="form-control"
                type="number"
                min="0.1"
                step="any"
                required
                placeholder="e.g. 500"
                value={quantity}
                onChange={e => setQuantity(e.target.value)}
              />

              <label>Unit</label>
              <select
                className="form-control"
                value={unit}
                onChange={e => setUnit(e.target.value as UnitType)}
              >
                <option value="g">Grams (g)</option>
                <option value="kg">Kilograms (kg)</option>
                <option value="ml">Millilitres (ml)</option>
                <option value="l">Litres (L)</option>
                <option value="pcs">Pieces (pcs)</option>
              </select>

              <label>Expiry date (Optional)</label>
              <input
                className="form-control"
                type="date"
                value={expiry}
                onChange={e => setExpiry(e.target.value)}
              />

              <label>Estimated price (₹ per unit, Optional)</label>
              <input
                className="form-control"
                type="number"
                step="any"
                placeholder="₹"
                value={price}
                onChange={e => setPrice(e.target.value)}
              />

              <button className="primary-btn full-btn" type="submit">
                Save ingredient
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
