import React from 'react';
import { useKitchen } from '../context/KitchenContext';

export const ShoppingView: React.FC = () => {
  const { getShoppingItems, checkedShopping, toggleShoppingItem, clearCheckedShopping } = useKitchen();

  const items = getShoppingItems();
  const doneCount = items.filter(i => checkedShopping.includes(i.name.toLowerCase())).length;
  const totalCost = items.reduce((sum, i) => sum + (i.amount * (i.price || 0.15)), 0);

  const categories = {
    'Fresh Produce': ['tomato', 'onion', 'spinach', 'potato', 'cucumber', 'carrot', 'lemon', 'avocado', 'basil', 'garlic'],
    'Dairy & Protein': ['paneer', 'milk', 'cream', 'egg', 'yoghurt', 'butter'],
    'Pantry Staples': ['rice', 'pasta', 'oat', 'flour', 'oil', 'honey', 'chickpea', 'bread', 'coconut'],
    'Other Essentials': []
  };

  const grouped: Record<string, typeof items> = {};
  items.forEach(item => {
    let cat = 'Other Essentials';
    for (const [groupName, keywords] of Object.entries(categories)) {
      if (groupName === 'Other Essentials') continue;
      if (keywords.some(k => item.name.toLowerCase().includes(k))) {
        cat = groupName;
        break;
      }
    }
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(item);
  });

  const handleWhatsApp = () => {
    let text = `🛒 *WEEKWOK GROCERY LIST*\n\n`;
    items.forEach(item => {
      const isChecked = checkedShopping.includes(item.name.toLowerCase());
      text += `${isChecked ? '✅' : '☐'} *${item.name}*: ${Math.round(item.amount * 10) / 10} ${item.unit}\n`;
    });
    text += `\n🌿 Planned with WeekWok.`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const progressPct = items.length > 0 ? (doneCount / items.length) * 100 : 0;

  return (
    <div className="page active">
      <div className="page-heading">
        <div>
          <span className="eyebrow">THE MARKET EDIT</span>
          <h1>Gather the <em>good things.</em></h1>
          <p>Calculated dynamically: planned incomplete meals minus active pantry stock.</p>
        </div>

        <div className="shopping-total">
          <span>ESTIMATED TOTAL</span>
          <strong>₹{Math.round(totalCost)}</strong>
        </div>
      </div>

      <div className="shopping-progress">
        <div>
          <strong>{doneCount} / {items.length}</strong>
          <span>items collected</span>
        </div>
        <div className="progress-track">
          <div className="progress-fill" style={{ width: `${progressPct}%` }}></div>
        </div>
      </div>

      <div className="shopping-actions">
        <span>{items.length === 0 ? 'Pantry covers all planned meals.' : `${items.length - doneCount} items left to pick up.`}</span>

        <div className="shopping-action-buttons">
          <button className="outline-btn" onClick={clearCheckedShopping}>Clear checked items</button>
          <button className="secondary-btn-sm" onClick={() => window.print()}>Print list 🖨️</button>
          <button className="outline-btn" onClick={handleWhatsApp}>Share on WhatsApp ↗</button>
        </div>
      </div>

      <div className="shopping-grid">
        {Object.entries(grouped).map(([cat, entries]) => (
          <section key={cat} className="shopping-category">
            <h3>{cat}</h3>
            <small>WEEKLY GAP REQUIREMENTS</small>
            {entries.map((item, idx) => {
              const isChecked = checkedShopping.includes(item.name.toLowerCase());
              return (
                <div key={idx} className={`shopping-item ${isChecked ? 'checked' : ''}`}>
                  <label>
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => toggleShoppingItem(item.name)}
                    />
                    <span>{item.name}</span>
                  </label>
                  <small>{Math.round(item.amount * 10) / 10} {item.unit}</small>
                </div>
              );
            })}
          </section>
        ))}
      </div>
    </div>
  );
};
