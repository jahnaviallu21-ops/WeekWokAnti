import React from 'react';
import { useKitchen } from '../context/KitchenContext';
import { Recipe } from '../types';

interface HomeViewProps {
  onNavigate: (page: string) => void;
  onOpenRecipe: (recipe: Recipe) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ onNavigate, onOpenRecipe }) => {
  const { plan, pantry, getShoppingItems, recipes } = useKitchen();

  const mealsPlannedCount = Object.keys(plan).filter((k) => plan[k]).length;
  const shoppingGapsCount = getShoppingItems().length;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiringCount = pantry.filter((item) => {
    if (!item.expiry) return false;
    const exp = new Date(item.expiry + 'T00:00:00');
    const diff = Math.ceil((exp.getTime() - today.getTime()) / 86400000);
    return diff >= 0 && diff <= 3;
  }).length;

  const plannedList = Object.entries(plan)
    .filter(([_, id]) => id)
    .slice(0, 4)
    .map(([key, id]) => {
      const recipe = recipes.find((r) => r.id === id);
      const [dayIdx, slotIdx] = key.split('-').map(Number);
      const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
      const slots = ['Breakfast', 'Lunch', 'Dinner'];
      return { recipe, day: days[dayIdx], slot: slots[slotIdx] };
    });

  return (
    <div className="page active">
      <div className="hero">
        <div className="hero-content">
          <span className="eyebrow">A MORE THOUGHTFUL WAY TO EAT</span>
          <h1>Make room for<br /><em>something delicious.</em></h1>
          <p>
            Plan your meals, maintain your live pantry inventory, and automatically
            generate accurate grocery gap lists in one unified, elegant workspace.
          </p>
          <div className="hero-actions">
            <button className="primary-btn" onClick={() => onNavigate('planner')}>
              Plan your week <span>↗</span>
            </button>
            <button className="outline-btn" onClick={() => onNavigate('recipes')}>
              Explore {recipes.length} recipes
            </button>
          </div>
        </div>

        <div className="hero-image">
          <img
            src="https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&w=1200&q=85"
            alt="Artisanal meal prep"
          />
          <div className="image-card">
            <span>✳</span>
            <div>
              <strong>SRS 3.3 Smart Stock Engine</strong>
              <small>React & TypeScript Full-Stack Phase</small>
            </div>
          </div>
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card" onClick={() => onNavigate('planner')}>
          <div className="stat-header">
            <span>MEALS PLANNED</span>
            <span className="stat-icon">▦</span>
          </div>
          <strong>{mealsPlannedCount}</strong>
          <small>This week's calendar</small>
        </div>

        <div className="stat-card" onClick={() => onNavigate('pantry')}>
          <div className="stat-header">
            <span>PANTRY ITEMS</span>
            <span className="stat-icon">◈</span>
          </div>
          <strong>{pantry.length}</strong>
          <small>Ingredients in stock</small>
        </div>

        <div className="stat-card" onClick={() => onNavigate('shopping')}>
          <div className="stat-header">
            <span>SHOPPING GAPS</span>
            <span className="stat-icon">🛒</span>
          </div>
          <strong>{shoppingGapsCount}</strong>
          <small>Ingredients to purchase</small>
        </div>

        <div className="stat-card" onClick={() => onNavigate('pantry')}>
          <div className="stat-header">
            <span>EXPIRING SOON</span>
            <span className="stat-icon">⚠️</span>
          </div>
          <strong>{expiringCount}</strong>
          <small>Within 3 days</small>
        </div>
      </div>

      <div className="section-heading">
        <div>
          <span className="eyebrow">YOUR WEEK AT A GLANCE</span>
          <h2>A little look ahead.</h2>
        </div>
        <button className="simple-link" onClick={() => onNavigate('planner')}>
          View full calendar →
        </button>
      </div>

      <div className="home-meals">
        {plannedList.length === 0 ? (
          <div className="home-meal-card" style={{ gridColumn: '1 / -1', padding: '30px', textAlign: 'center' }}>
            <small>YOUR TABLE IS EMPTY</small>
            <h3>No meals planned yet.</h3>
            <p>Select a recipe to schedule your first meal.</p>
          </div>
        ) : (
          plannedList.map(({ recipe, day, slot }, idx) =>
            recipe ? (
              <article
                key={idx}
                className="home-meal-card"
                onClick={() => onOpenRecipe(recipe)}
              >
                <img src={recipe.image} alt={recipe.name} />
                <div>
                  <small>{day?.toUpperCase()} · {slot?.toUpperCase()}</small>
                  <h3>{recipe.name}</h3>
                  <p>◷ {recipe.time} min · {recipe.category}</p>
                </div>
              </article>
            ) : null
          )
        )}
      </div>
    </div>
  );
};
