import React, { useState } from 'react';
import { useKitchen } from '../context/KitchenContext';
import { DeductionMode } from '../types';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;
  const { settings, updateSettings, resetAllData } = useKitchen();

  const [kitchenName, setKitchenName] = useState(settings.kitchenName);
  const [chefName, setChefName] = useState(settings.chefName);
  const [deductionMode, setDeductionMode] = useState<DeductionMode>(settings.deductionMode);
  const [weeklyBudget, setWeeklyBudget] = useState(settings.weeklyBudget);
  const [diet, setDiet] = useState(settings.dietPreference);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      kitchenName,
      chefName,
      deductionMode,
      weeklyBudget: Number(weeklyBudget),
      dietPreference: diet
    });
    onClose();
  };

  return (
    <div className="modal-overlay open">
      <div className="modal small-modal">
        <button className="modal-close" onClick={onClose}>×</button>
        <span className="eyebrow">WORKSPACE PREFERENCES</span>
        <h2>Kitchen <em>Settings.</em></h2>

        <form onSubmit={handleSubmit}>
          <label>Kitchen Name</label>
          <input
            className="form-control"
            value={kitchenName}
            onChange={e => setKitchenName(e.target.value)}
            required
          />

          <label>Chef Name</label>
          <input
            className="form-control"
            value={chefName}
            onChange={e => setChefName(e.target.value)}
            required
          />

          <label>Pantry Stock Deduction Engine (SRS 3.3)</label>
          <select
            className="form-control"
            value={deductionMode}
            onChange={e => setDeductionMode(e.target.value as DeductionMode)}
          >
            <option value="SRS_3_3_SCHEDULE">SRS 3.3: Deduct on Schedule (Restores on Removal)</option>
            <option value="RESERVATION_COMPLETE">Reservation Mode: Reserve on Schedule, Deduct on Complete</option>
          </select>
          <small className="form-help-text">SRS 3.3 mode complies with academic evaluation requirements.</small>

          <label>Weekly Grocery Budget (₹)</label>
          <input
            className="form-control"
            type="number"
            value={weeklyBudget}
            onChange={e => setWeeklyBudget(Number(e.target.value))}
            min="500"
            step="100"
          />

          <label>Dietary Focus</label>
          <select
            className="form-control"
            value={diet}
            onChange={e => setDiet(e.target.value)}
          >
            <option value="All">All Diets</option>
            <option value="Vegetarian">Vegetarian</option>
            <option value="High Protein">High Protein</option>
            <option value="Vegan">Vegan</option>
          </select>

          <div className="settings-modal-actions">
            <button className="primary-btn full-btn" type="submit">
              Save Settings
            </button>
            <button
              type="button"
              className="secondary-btn full-btn"
              onClick={() => {
                if (confirm('Reset workspace data to defaults?')) {
                  resetAllData();
                  onClose();
                }
              }}
            >
              Reset to Fresh Sample Data
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
