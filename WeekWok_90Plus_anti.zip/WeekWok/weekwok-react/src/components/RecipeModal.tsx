import React, { useState } from 'react';
import { useKitchen } from '../context/KitchenContext';
import { Recipe } from '../types';

interface RecipeModalProps {
  recipe: Recipe | null;
  onClose: () => void;
  onAddToPlanner: (recipe: Recipe) => void;
}

export const RecipeModal: React.FC<RecipeModalProps> = ({ recipe, onClose, onAddToPlanner }) => {
  if (!recipe) return null;
  const { getPantryAvailability } = useKitchen();
  const [servings, setServings] = useState(recipe.servings);

  const availability = getPantryAvailability();

  const scaledPrice = Math.round((recipe.price * servings) / recipe.servings);
  const scaledCalories = Math.round((recipe.calories * servings) / recipe.servings);

  return (
    <div className="modal-overlay open">
      <div className="modal recipe-modal">
        <button className="modal-close" onClick={onClose}>×</button>
        <div className="recipe-detail-layout">
          <img className="recipe-detail-image" src={recipe.image} alt={recipe.name} />
          <div className="recipe-detail-content">
            <span className="eyebrow">{recipe.category.toUpperCase()} · WEEKWOK COLLECTION</span>
            <h2>{recipe.name}</h2>
            <p>{recipe.description}</p>

            <div className="detail-meta">
              <span>◷ {recipe.time} min</span>
              <span>₹{scaledPrice} approx</span>
              <span>⚡ {scaledCalories} kcal</span>
            </div>

            <div className="serving-row">
              <span>Servings:</span>
              <button onClick={() => setServings(s => Math.max(1, s - 1))}>−</button>
              <strong>{servings}</strong>
              <button onClick={() => setServings(s => Math.min(20, s + 1))}>+</button>
            </div>

            <h3>Ingredients</h3>
            {recipe.ingredients.map((ing, i) => {
              const scaled = (ing.amount * servings) / recipe.servings;
              const inStock = availability[ing.name.toLowerCase()];
              const missing = Math.max(0, scaled - (inStock?.available || 0));

              return (
                <div key={i} className="ingredient-row">
                  <span>{ing.name}</span>
                  <small>
                    {Math.round(scaled * 10) / 10} {ing.unit}
                    {missing > 0 ? (
                      <span style={{ color: '#8EB69B' }}> · Need {Math.round(missing * 10) / 10} {ing.unit}</span>
                    ) : (
                      ' · In pantry ✓'
                    )}
                  </small>
                </div>
              );
            })}

            <h3 style={{ marginTop: 18 }}>Preparation Method</h3>
            <ol className="instructions">
              {recipe.instructions.map((step, i) => (
                <li key={i}>{step}</li>
              ))}
            </ol>

            <div className="recipe-detail-actions">
              <button className="primary-btn" onClick={() => onAddToPlanner(recipe)}>
                Add to meal plan ↗
              </button>
              <button className="outline-btn" onClick={onClose}>
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
