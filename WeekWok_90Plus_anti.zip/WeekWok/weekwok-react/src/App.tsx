import { useState } from 'react';
import './App.css';
import { KitchenProvider } from './context/KitchenContext';
import { Sidebar } from './components/Sidebar';
import { Topbar } from './components/Topbar';
import { Toast } from './components/Toast';
import { HomeView } from './components/HomeView';
import { PlannerView } from './components/PlannerView';
import { RecipeCatalog } from './components/RecipeCatalog';
import { RecipeModal } from './components/RecipeModal';
import { PantryView } from './components/PantryView';
import { ShoppingView } from './components/ShoppingView';
import { AnalyticsView } from './components/AnalyticsView';
import { ProfileModal } from './components/ProfileModal';
import { Recipe } from './types';

function KitchenApp() {
  const [activePage, setActivePage] = useState('home');
  const [activeRecipe, setActiveRecipe] = useState<Recipe | null>(null);
  const [profileOpen, setProfileOpen] = useState(false);

  return (
    <div className="app">
      <Sidebar
        activePage={activePage}
        setActivePage={setActivePage}
        onOpenProfile={() => setProfileOpen(true)}
      />

      <main className="main-content">
        <Topbar onQuickCook={() => setActivePage('recipes')} />

        {activePage === 'home' && (
          <HomeView
            onNavigate={setActivePage}
            onOpenRecipe={setActiveRecipe}
          />
        )}

        {activePage === 'planner' && (
          <PlannerView
            onOpenRecipe={setActiveRecipe}
            onOpenSettings={() => setProfileOpen(true)}
          />
        )}

        {activePage === 'recipes' && (
          <RecipeCatalog
            onOpenRecipe={setActiveRecipe}
          />
        )}

        {activePage === 'pantry' && <PantryView />}

        {activePage === 'shopping' && <ShoppingView />}

        {activePage === 'analytics' && <AnalyticsView />}

        <RecipeModal
          recipe={activeRecipe}
          onClose={() => setActiveRecipe(null)}
          onAddToPlanner={() => {
            setActiveRecipe(null);
            setActivePage('planner');
          }}
        />

        <ProfileModal
          isOpen={profileOpen}
          onClose={() => setProfileOpen(false)}
        />

        <Toast />
      </main>
    </div>
  );
}

export default function App() {
  return (
    <KitchenProvider>
      <KitchenApp />
    </KitchenProvider>
  );
}
