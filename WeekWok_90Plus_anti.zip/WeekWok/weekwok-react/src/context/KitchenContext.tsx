import React, { createContext, useContext, useState, useEffect } from 'react';
import { Recipe, PantryItem, KitchenSettings, UnitType, ShoppingGapItem, PantryAvailability } from '../types';
import { RECIPES_DATA, INITIAL_PANTRY, INITIAL_SETTINGS } from '../data/recipes';

interface KitchenContextType {
  recipes: Recipe[];
  pantry: PantryItem[];
  plan: Record<string, number>;
  completed: string[];
  settings: KitchenSettings;
  checkedShopping: string[];
  weekOffset: number;
  toastMessage: string | null;
  showToast: (msg: string) => void;
  setWeekOffset: React.Dispatch<React.SetStateAction<number>>;
  assignMeal: (day: number, slot: number, recipeId: number) => void;
  removeMeal: (key: string) => void;
  completeMeal: (key: string) => void;
  addPantryItem: (item: Omit<PantryItem, 'id'>) => void;
  deletePantryItem: (id: number) => void;
  toggleShoppingItem: (name: string) => void;
  clearCheckedShopping: () => void;
  updateSettings: (newSettings: Partial<KitchenSettings>) => void;
  resetAllData: () => void;
  getPantryAvailability: () => Record<string, PantryAvailability>;
  getShoppingItems: () => ShoppingGapItem[];
}

const KitchenContext = createContext<KitchenContextType | undefined>(undefined);

function convertToBase(amount: number, unit: UnitType): { amount: number; unit: UnitType } {
  if (unit === 'kg') return { amount: amount * 1000, unit: 'g' };
  if (unit === 'l') return { amount: amount * 1000, unit: 'ml' };
  return { amount, unit };
}

export const KitchenProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [recipes] = useState<Recipe[]>(RECIPES_DATA);
  const [pantry, setPantry] = useState<PantryItem[]>(() => {
    const saved = localStorage.getItem('weekwok-react-pantry');
    return saved ? JSON.parse(saved) : INITIAL_PANTRY;
  });
  const [plan, setPlan] = useState<Record<string, number>>(() => {
    const saved = localStorage.getItem('weekwok-react-plan');
    return saved ? JSON.parse(saved) : {};
  });
  const [completed, setCompleted] = useState<string[]>(() => {
    const saved = localStorage.getItem('weekwok-react-completed');
    return saved ? JSON.parse(saved) : [];
  });
  const [checkedShopping, setCheckedShopping] = useState<string[]>(() => {
    const saved = localStorage.getItem('weekwok-react-checked');
    return saved ? JSON.parse(saved) : [];
  });
  const [settings, setSettings] = useState<KitchenSettings>(() => {
    const saved = localStorage.getItem('weekwok-react-settings');
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });
  const [weekOffset, setWeekOffset] = useState<number>(0);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('weekwok-react-pantry', JSON.stringify(pantry));
    localStorage.setItem('weekwok-react-plan', JSON.stringify(plan));
    localStorage.setItem('weekwok-react-completed', JSON.stringify(completed));
    localStorage.setItem('weekwok-react-checked', JSON.stringify(checkedShopping));
    localStorage.setItem('weekwok-react-settings', JSON.stringify(settings));
  }, [pantry, plan, completed, checkedShopping, settings]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const getPantryAvailability = (): Record<string, PantryAvailability> => {
    const avail: Record<string, PantryAvailability> = {};
    pantry.forEach(p => {
      const base = convertToBase(p.quantity, p.unit);
      const name = p.name.trim().toLowerCase();

      let reserved = 0;
      if (settings.deductionMode === 'RESERVATION_COMPLETE') {
        Object.entries(plan).forEach(([k, rId]) => {
          if (!rId || completed.includes(k)) return;
          const r = recipes.find(x => x.id === rId);
          if (!r) return;
          r.ingredients.forEach(i => {
            if (i.name.trim().toLowerCase() === name) {
              const ib = convertToBase(i.amount, i.unit);
              if (ib.unit === base.unit) reserved += ib.amount;
            }
          });
        });
      }

      avail[name] = {
        stock: base.amount,
        reserved,
        available: Math.max(0, base.amount - reserved),
        unit: base.unit
      };
    });
    return avail;
  };

  const getShoppingItems = (): ShoppingGapItem[] => {
    const reqs: Record<string, { name: string; amount: number; unit: UnitType }> = {};

    Object.entries(plan).forEach(([k, rId]) => {
      if (!rId || completed.includes(k)) return;
      const r = recipes.find(x => x.id === rId);
      if (!r) return;

      r.ingredients.forEach(ing => {
        const name = ing.name.trim().toLowerCase();
        const base = convertToBase(ing.amount, ing.unit);

        if (!reqs[name]) {
          reqs[name] = { name: ing.name, amount: 0, unit: base.unit };
        }
        if (reqs[name].unit === base.unit) {
          reqs[name].amount += base.amount;
        }
      });
    });

    const items: ShoppingGapItem[] = [];
    Object.values(reqs).forEach(req => {
      const p = pantry.find(x => x.name.trim().toLowerCase() === req.name.trim().toLowerCase());
      const stockAmount = p ? convertToBase(p.quantity, p.unit).amount : 0;

      const gap = settings.deductionMode === 'SRS_3_3_SCHEDULE'
        ? req.amount
        : Math.max(0, req.amount - stockAmount);

      if (gap > 0) {
        items.push({
          name: req.name,
          amount: gap,
          unit: req.unit,
          price: p?.price || 0.15
        });
      }
    });

    return items;
  };

  const assignMeal = (day: number, slot: number, recipeId: number) => {
    const key = `${day}-${slot}`;
    const recipe = recipes.find(r => r.id === recipeId);
    if (!recipe) return;

    // SRS 3.3 Stock Deduction Engine
    if (settings.deductionMode === 'SRS_3_3_SCHEDULE') {
      setPantry(prev => {
        const next = [...prev];
        recipe.ingredients.forEach(ing => {
          const needed = convertToBase(ing.amount, ing.unit);
          const item = next.find(x => x.name.trim().toLowerCase() === ing.name.trim().toLowerCase());
          if (item) {
            const cur = convertToBase(item.quantity, item.unit);
            if (cur.unit === needed.unit) {
              item.quantity = Math.max(0, cur.amount - needed.amount);
              item.unit = cur.unit;
            }
          }
        });
        return next;
      });
    }

    setPlan(prev => ({ ...prev, [key]: recipeId }));
    setCompleted(prev => prev.filter(k => k !== key));
    showToast(`Scheduled ${recipe.name} (SRS 3.3 stock updated)`);
  };

  const removeMeal = (key: string) => {
    const recipeId = plan[key];
    const recipe = recipes.find(r => r.id === recipeId);

    // SRS 3.3 Restitution
    if (recipe && settings.deductionMode === 'SRS_3_3_SCHEDULE') {
      setPantry(prev => {
        const next = [...prev];
        recipe.ingredients.forEach(ing => {
          const toRestore = convertToBase(ing.amount, ing.unit);
          const item = next.find(x => x.name.trim().toLowerCase() === ing.name.trim().toLowerCase());
          if (item) {
            const cur = convertToBase(item.quantity, item.unit);
            if (cur.unit === toRestore.unit) {
              item.quantity = cur.amount + toRestore.amount;
            }
          } else {
            next.push({
              id: Date.now() + Math.random(),
              name: ing.name,
              quantity: toRestore.amount,
              unit: toRestore.unit,
              price: 0.15
            });
          }
        });
        return next;
      });
    }

    setPlan(prev => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
    setCompleted(prev => prev.filter(k => k !== key));
    showToast('Meal removed and pantry stock restored');
  };

  const completeMeal = (key: string) => {
    if (!completed.includes(key)) {
      setCompleted(prev => [...prev, key]);
    }
    showToast('Meal marked completed!');
  };

  const addPantryItem = (item: Omit<PantryItem, 'id'>) => {
    setPantry(prev => {
      const existing = prev.find(p => p.name.trim().toLowerCase() === item.name.trim().toLowerCase());
      if (existing) {
        return prev.map(p => p.id === existing.id ? { ...p, quantity: p.quantity + item.quantity } : p);
      }
      return [...prev, { ...item, id: Date.now() }];
    });
    showToast(`${item.name} added to pantry`);
  };

  const deletePantryItem = (id: number) => {
    setPantry(prev => prev.filter(p => p.id !== id));
    showToast('Pantry item removed');
  };

  const toggleShoppingItem = (name: string) => {
    const key = name.trim().toLowerCase();
    setCheckedShopping(prev =>
      prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key]
    );
  };

  const clearCheckedShopping = () => {
    setCheckedShopping([]);
    showToast('Checked items cleared');
  };

  const updateSettings = (newSettings: Partial<KitchenSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
    showToast('Kitchen settings updated');
  };

  const resetAllData = () => {
    setPantry(INITIAL_PANTRY);
    setPlan({});
    setCompleted([]);
    setCheckedShopping([]);
    setSettings(INITIAL_SETTINGS);
    showToast('Workspace reset to defaults');
  };

  return (
    <KitchenContext.Provider value={{
      recipes,
      pantry,
      plan,
      completed,
      settings,
      checkedShopping,
      weekOffset,
      toastMessage,
      showToast,
      setWeekOffset,
      assignMeal,
      removeMeal,
      completeMeal,
      addPantryItem,
      deletePantryItem,
      toggleShoppingItem,
      clearCheckedShopping,
      updateSettings,
      resetAllData,
      getPantryAvailability,
      getShoppingItems
    }}>
      {children}
    </KitchenContext.Provider>
  );
};

export const useKitchen = () => {
  const ctx = useContext(KitchenContext);
  if (!ctx) throw new Error('useKitchen must be used within KitchenProvider');
  return ctx;
};
