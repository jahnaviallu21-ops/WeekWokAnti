/**
 * WeekWok TypeScript Domain Models & Interfaces
 */

export type UnitType = 'g' | 'kg' | 'ml' | 'l' | 'pcs';

export type RecipeCategory = 'Breakfast' | 'Lunch' | 'Dinner' | 'Snacks';

export interface Ingredient {
  name: string;
  amount: number;
  unit: UnitType;
}

export interface Recipe {
  id: number;
  name: string;
  category: RecipeCategory;
  time: number;
  servings: number;
  price: number;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  image: string;
  description: string;
  ingredients: Ingredient[];
  instructions: string[];
}

export interface PantryItem {
  id: number;
  name: string;
  quantity: number;
  unit: UnitType;
  expiry?: string | null;
  price?: number;
}

export type MealPlanMap = Record<string, number>; // key: `${dayIndex}-${slotIndex}` => recipeId

export type DeductionMode = 'SRS_3_3_SCHEDULE' | 'RESERVATION_COMPLETE';

export interface KitchenSettings {
  kitchenName: string;
  chefName: string;
  deductionMode: DeductionMode;
  weeklyBudget: number;
  dietPreference: string;
}

export interface ShoppingGapItem {
  name: string;
  amount: number;
  unit: UnitType;
  price: number;
}

export interface PantryAvailability {
  stock: number;
  reserved: number;
  available: number;
  unit: UnitType;
}
