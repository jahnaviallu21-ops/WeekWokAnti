/**
 * WeekWok 3-Tier Database Service (SQLite)
 * Uses native node:sqlite (zero external dependencies) with resilient fallback
 */

const fs = require('fs');
const path = require('path');

let DatabaseSync;
try {
  DatabaseSync = require('node:sqlite').DatabaseSync;
} catch (e) {
  DatabaseSync = null;
}

const DB_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

const DB_FILE = path.join(DB_DIR, 'weekwok.sqlite');

class DatabaseService {
  constructor() {
    this.init();
  }

  init() {
    if (DatabaseSync) {
      this.db = new DatabaseSync(DB_FILE);
      this.isNative = true;
    } else {
      console.warn('[WeekWok DB] node:sqlite not found, using memory fallback');
      this.memoryStore = {
        users: [],
        recipes: [],
        pantry: [],
        plans: [],
        checks: [],
        settings: []
      };
      this.isNative = false;
    }

    this.runSchema();
    this.seedDefaultData();
  }

  runSchema() {
    if (!this.isNative) return;
    const schemaPath = path.join(__dirname, 'schema.sql');
    if (fs.existsSync(schemaPath)) {
      const sql = fs.readFileSync(schemaPath, 'utf8');
      this.db.exec(sql);
    }
  }

  seedDefaultData() {
    if (!this.isNative) return;

    // Check if user exists
    const userCheck = this.db.prepare('SELECT COUNT(*) as count FROM users').get();
    if (userCheck.count === 0) {
      this.db.prepare(`
        INSERT INTO users (id, username, email, kitchen_name, dietary_preference)
        VALUES (1, 'default_chef', 'chef@weekwok.internal', 'My Kitchen', 'All')
      `).run();

      this.db.prepare(`
        INSERT INTO kitchen_settings (user_id, deduction_mode, weekly_budget)
        VALUES (1, 'SRS_3_3_SCHEDULE', 2500.0)
      `).run();
    }

    // Check if recipes exist
    const recipeCheck = this.db.prepare('SELECT COUNT(*) as count FROM recipes').get();
    if (recipeCheck.count === 0) {
      const defaultRecipes = require('./defaultData').recipes;
      const insertRecipe = this.db.prepare(`
        INSERT INTO recipes (id, name, category, time_minutes, servings, price, image, description, ingredients_json, instructions_json, calories, protein_g, carbs_g, fat_g)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      for (const r of defaultRecipes) {
        insertRecipe.run(
          r.id,
          r.name,
          r.category,
          r.time,
          r.servings,
          r.price || 120,
          r.image,
          r.description,
          JSON.stringify(r.ingredients),
          JSON.stringify(r.instructions),
          r.calories || 380,
          r.protein || 14,
          r.carbs || 45,
          r.fat || 12
        );
      }
    }

    // Check if pantry items exist
    const pantryCheck = this.db.prepare('SELECT COUNT(*) as count FROM pantry_items').get();
    if (pantryCheck.count === 0) {
      const defaultPantry = require('./defaultData').pantry;
      const insertPantry = this.db.prepare(`
        INSERT INTO pantry_items (user_id, name, quantity, unit, expiry, price)
        VALUES (1, ?, ?, ?, ?, ?)
      `);

      for (const p of defaultPantry) {
        insertPantry.run(
          p.name,
          p.quantity,
          p.unit,
          p.expiry || null,
          p.price || 0.15
        );
      }
    }
  }

  // --- Recipes ---
  getRecipes(category = null, search = '') {
    let query = 'SELECT * FROM recipes WHERE 1=1';
    const params = [];

    if (category && category !== 'all') {
      query += ' AND category = ?';
      params.push(category);
    }
    if (search) {
      query += ' AND (name LIKE ? OR description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    const rows = this.db.prepare(query).all(...params);
    return rows.map(r => ({
      ...r,
      time: r.time_minutes,
      ingredients: JSON.parse(r.ingredients_json),
      instructions: JSON.parse(r.instructions_json)
    }));
  }

  getRecipeById(id) {
    const r = this.db.prepare('SELECT * FROM recipes WHERE id = ?').get(id);
    if (!r) return null;
    return {
      ...r,
      time: r.time_minutes,
      ingredients: JSON.parse(r.ingredients_json),
      instructions: JSON.parse(r.instructions_json)
    };
  }

  // --- Pantry Items ---
  getPantry(userId = 1) {
    return this.db.prepare('SELECT * FROM pantry_items WHERE user_id = ? ORDER BY name ASC').all(userId);
  }

  addOrUpdatePantryItem(userId = 1, { name, quantity, unit, expiry = null, price = 0 }) {
    const existing = this.db.prepare('SELECT * FROM pantry_items WHERE user_id = ? AND LOWER(TRIM(name)) = LOWER(TRIM(?))').get(userId, name);
    
    if (existing) {
      // Check unit compatibility
      const newQty = existing.quantity + Number(quantity);
      this.db.prepare(`
        UPDATE pantry_items
        SET quantity = ?, expiry = COALESCE(?, expiry), price = CASE WHEN ? > 0 THEN ? ELSE price END, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(newQty, expiry, price, price, existing.id);
      return this.db.prepare('SELECT * FROM pantry_items WHERE id = ?').get(existing.id);
    } else {
      const res = this.db.prepare(`
        INSERT INTO pantry_items (user_id, name, quantity, unit, expiry, price)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(userId, name, Number(quantity), unit, expiry, price);
      return { id: res.lastInsertRowid, user_id: userId, name, quantity, unit, expiry, price };
    }
  }

  updatePantryQuantity(id, quantity) {
    this.db.prepare('UPDATE pantry_items SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(Math.max(0, quantity), id);
    return this.db.prepare('SELECT * FROM pantry_items WHERE id = ?').get(id);
  }

  deletePantryItem(id, userId = 1) {
    this.db.prepare('DELETE FROM pantry_items WHERE id = ? AND user_id = ?').run(id, userId);
    return { success: true, deletedId: id };
  }

  // --- Meal Plans ---
  getMealPlans(userId = 1) {
    const plans = this.db.prepare(`
      SELECT mp.*, r.name as recipe_name, r.category as recipe_category, r.time_minutes, r.image as recipe_image
      FROM meal_plans mp
      JOIN recipes r ON mp.recipe_id = r.id
      WHERE mp.user_id = ?
    `).all(userId);

    // Convert into key format { "dayIndex-slotIndex": recipe_id }
    const planMap = {};
    const completedList = [];

    plans.forEach(p => {
      const key = `${p.day_index}-${p.slot_index}`;
      planMap[key] = p.recipe_id;
      if (p.status === 'completed') {
        completedList.push(key);
      }
    });

    return { raw: plans, planMap, completedList };
  }

  assignMealPlan(userId = 1, { day_index, slot_index, recipe_id, date_str, servings = 2, deduction_mode = 'SRS_3_3_SCHEDULE' }) {
    // Delete any existing meal at this slot
    this.db.prepare(`
      DELETE FROM meal_plans
      WHERE user_id = ? AND day_index = ? AND slot_index = ?
    `).run(userId, day_index, slot_index);

    const res = this.db.prepare(`
      INSERT INTO meal_plans (user_id, day_index, slot_index, recipe_id, servings, status, date_str, deducted_at)
      VALUES (?, ?, ?, ?, ?, 'scheduled', ?, CURRENT_TIMESTAMP)
    `).run(userId, day_index, slot_index, recipe_id, servings, date_str || new Date().toISOString().slice(0, 10));

    return { id: res.lastInsertRowid, day_index, slot_index, recipe_id, servings };
  }

  removeMealPlan(userId = 1, day_index, slot_index) {
    this.db.prepare(`
      DELETE FROM meal_plans
      WHERE user_id = ? AND day_index = ? AND slot_index = ?
    `).run(userId, day_index, slot_index);
    return { success: true };
  }

  completeMealPlan(userId = 1, day_index, slot_index) {
    this.db.prepare(`
      UPDATE meal_plans
      SET status = 'completed'
      WHERE user_id = ? AND day_index = ? AND slot_index = ?
    `).run(userId, day_index, slot_index);
    return { success: true };
  }

  // --- Shopping List Checks ---
  getShoppingChecks(userId = 1) {
    const rows = this.db.prepare('SELECT item_key FROM shopping_checks WHERE user_id = ? AND is_checked = 1').all(userId);
    return rows.map(r => r.item_key);
  }

  toggleShoppingCheck(userId = 1, itemKey, isChecked) {
    this.db.prepare(`
      INSERT INTO shopping_checks (user_id, item_key, is_checked, updated_at)
      VALUES (?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(user_id, item_key) DO UPDATE SET is_checked = excluded.is_checked, updated_at = CURRENT_TIMESTAMP
    `).run(userId, itemKey, isChecked ? 1 : 0);
    return { success: true, itemKey, isChecked };
  }

  // --- Settings ---
  getSettings(userId = 1) {
    return this.db.prepare('SELECT * FROM kitchen_settings WHERE user_id = ?').get(userId) || {
      deduction_mode: 'SRS_3_3_SCHEDULE',
      weekly_budget: 2500.0
    };
  }

  updateSettings(userId = 1, { deduction_mode, weekly_budget }) {
    this.db.prepare(`
      UPDATE kitchen_settings
      SET deduction_mode = COALESCE(?, deduction_mode),
          weekly_budget = COALESCE(?, weekly_budget),
          updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ?
    `).run(deduction_mode, weekly_budget, userId);
    return this.getSettings(userId);
  }

  // --- Transactions Log ---
  logStockTransaction(userId = 1, planKey, ingredientName, quantityChanged, unit, actionType) {
    this.db.prepare(`
      INSERT INTO stock_transactions (user_id, plan_key, ingredient_name, quantity_changed, unit, action_type)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(userId, planKey, ingredientName, quantityChanged, unit, actionType);
  }
}

module.exports = new DatabaseService();
