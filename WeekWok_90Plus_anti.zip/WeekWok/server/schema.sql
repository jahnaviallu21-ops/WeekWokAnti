-- ======================================================================
-- WEEKWOK: 3-TIER RELATIONAL DATABASE SCHEMA (SQLite)
-- Grade: 90+ Standard Academic System Design
-- ======================================================================

PRAGMA foreign_keys = ON;

-- 1. Users & Kitchen Workspaces
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    email TEXT UNIQUE,
    kitchen_name TEXT DEFAULT 'My Kitchen',
    dietary_preference TEXT DEFAULT 'All',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. Recipe Catalog & Nutritional Information
CREATE TABLE IF NOT EXISTS recipes (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL CHECK(category IN ('Breakfast', 'Lunch', 'Dinner', 'Snacks', 'Dessert')),
    time_minutes INTEGER NOT NULL CHECK(time_minutes > 0),
    servings INTEGER NOT NULL DEFAULT 2 CHECK(servings > 0),
    price REAL NOT NULL DEFAULT 0.0,
    image TEXT NOT NULL,
    description TEXT NOT NULL,
    ingredients_json TEXT NOT NULL, -- Array of {name, amount, unit}
    instructions_json TEXT NOT NULL, -- Array of strings
    calories INTEGER DEFAULT 350,
    protein_g REAL DEFAULT 15.0,
    carbs_g REAL DEFAULT 40.0,
    fat_g REAL DEFAULT 12.0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 3. Pantry Inventory Tracking
CREATE TABLE IF NOT EXISTS pantry_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL DEFAULT 1,
    name TEXT NOT NULL,
    quantity REAL NOT NULL CHECK(quantity >= 0),
    unit TEXT NOT NULL CHECK(unit IN ('g', 'kg', 'ml', 'l', 'pcs')),
    expiry DATE,
    price REAL DEFAULT 0.0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 4. 7-Day Weekly Meal Planner
CREATE TABLE IF NOT EXISTS meal_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL DEFAULT 1,
    day_index INTEGER NOT NULL CHECK(day_index BETWEEN 0 AND 6),
    slot_index INTEGER NOT NULL CHECK(slot_index BETWEEN 0 AND 2),
    recipe_id INTEGER NOT NULL,
    servings INTEGER DEFAULT 2,
    status TEXT DEFAULT 'scheduled' CHECK(status IN ('scheduled', 'completed', 'cancelled')),
    date_str TEXT NOT NULL, -- e.g. '2026-11-21'
    deducted_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, day_index, slot_index, date_str),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (recipe_id) REFERENCES recipes(id) ON DELETE RESTRICT
);

-- 5. SRS 3.3 Pantry Stock Transaction Audit Log
CREATE TABLE IF NOT EXISTS stock_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL DEFAULT 1,
    plan_key TEXT NOT NULL, -- e.g. '0-1-2026-11-21'
    ingredient_name TEXT NOT NULL,
    quantity_changed REAL NOT NULL,
    unit TEXT NOT NULL,
    action_type TEXT NOT NULL CHECK(action_type IN ('SCHEDULE_DEDUCT', 'RESTITUTION', 'COMPLETE_DEDUCT', 'MANUAL_ADJUST')),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 6. Shopping List Checkmarks Persistence
CREATE TABLE IF NOT EXISTS shopping_checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL DEFAULT 1,
    item_key TEXT NOT NULL,
    is_checked INTEGER DEFAULT 0 CHECK(is_checked IN (0, 1)),
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, item_key),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 7. Kitchen Preferences & Engine Configurations
CREATE TABLE IF NOT EXISTS kitchen_settings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL UNIQUE DEFAULT 1,
    deduction_mode TEXT DEFAULT 'SRS_3_3_SCHEDULE' CHECK(deduction_mode IN ('SRS_3_3_SCHEDULE', 'RESERVATION_COMPLETE')),
    weekly_budget REAL DEFAULT 2500.0,
    theme TEXT DEFAULT 'forest_luxury',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Indexes for performance & quick lookups
CREATE INDEX IF NOT EXISTS idx_pantry_user_name ON pantry_items(user_id, name);
CREATE INDEX IF NOT EXISTS idx_meal_plans_lookup ON meal_plans(user_id, day_index, slot_index);
CREATE INDEX IF NOT EXISTS idx_recipes_category ON recipes(category);
