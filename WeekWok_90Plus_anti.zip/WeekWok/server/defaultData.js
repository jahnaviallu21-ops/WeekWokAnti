/**
 * WeekWok Seed Data - Recipes, Ingredients, and Pantry Stock
 * Includes Breakfast, Lunch, Dinner, and Snacks with rich nutritional metrics
 */

const recipes = [
  {
    id: 1,
    name: "Paneer Butter Masala",
    category: "Dinner",
    time: 35,
    servings: 2,
    price: 180,
    image: "https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=800",
    description: "A rich, creamy paneer curry with tomatoes and aromatic spices.",
    calories: 480,
    protein: 22,
    carbs: 24,
    fat: 34,
    ingredients: [
      { name: "Paneer", amount: 400, unit: "g" },
      { name: "Butter", amount: 50, unit: "g" },
      { name: "Tomatoes", amount: 250, unit: "g" },
      { name: "Cream", amount: 100, unit: "ml" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Heat butter and oil in a pan.",
      "Add chopped onions and cook until soft.",
      "Add tomatoes and spices. Cook until smooth.",
      "Add paneer cubes and cream.",
      "Simmer for 8–10 minutes and serve warm with naan or rice."
    ]
  },
  {
    id: 2,
    name: "Garden Harvest Bowl",
    category: "Lunch",
    time: 25,
    servings: 2,
    price: 120,
    image: "harvestgardenbowl.jpg",
    description: "A refreshing bowl filled with seasonal vegetables and greens.",
    calories: 290,
    protein: 10,
    carbs: 38,
    fat: 12,
    ingredients: [
      { name: "Tomatoes", amount: 150, unit: "g" },
      { name: "Cucumber", amount: 150, unit: "g" },
      { name: "Spinach", amount: 100, unit: "g" },
      { name: "Olive Oil", amount: 15, unit: "ml" },
      { name: "Lemons", amount: 1, unit: "pcs" }
    ],
    instructions: [
      "Wash and prepare all crisp garden vegetables.",
      "Chop the cucumber and ripe tomatoes into bite sizes.",
      "Combine with tender fresh spinach leaves in a bowl.",
      "Prepare a zesty lemon, sea salt, and extra virgin olive oil dressing.",
      "Toss thoroughly and serve chilled."
    ]
  },
  {
    id: 3,
    name: "Berry & Oat Bowl",
    category: "Breakfast",
    time: 10,
    servings: 2,
    price: 90,
    image: "berry&oatmeal.jpg",
    description: "A nourishing breakfast with rolled oats, fresh berries and creamy yoghurt.",
    calories: 340,
    protein: 16,
    carbs: 58,
    fat: 6,
    ingredients: [
      { name: "Rolled Oats", amount: 100, unit: "g" },
      { name: "Milk", amount: 250, unit: "ml" },
      { name: "Mixed Berries", amount: 100, unit: "g" },
      { name: "Honey", amount: 20, unit: "g" },
      { name: "Greek Yoghurt", amount: 100, unit: "g" }
    ],
    instructions: [
      "Simmer rolled oats gently with warm milk until creamy.",
      "Allow the oats to cool slightly for 2 minutes.",
      "Fold in rich Greek yoghurt and crown with mixed berries.",
      "Drizzle with golden honey and toasted seeds if desired."
    ]
  },
  {
    id: 4,
    name: "Avocado Sourdough",
    category: "Breakfast",
    time: 12,
    servings: 2,
    price: 110,
    image: "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800",
    description: "Artisanal toasted sourdough topped with creamy avocado and herbs.",
    calories: 380,
    protein: 11,
    carbs: 42,
    fat: 20,
    ingredients: [
      { name: "Bread", amount: 2, unit: "pcs" },
      { name: "Avocado", amount: 150, unit: "g" },
      { name: "Lemons", amount: 1, unit: "pcs" },
      { name: "Olive Oil", amount: 10, unit: "ml" }
    ],
    instructions: [
      "Toast sourdough slices until crisp and golden brown.",
      "Mash ripe avocado with freshly squeezed lemon juice, salt and chili flakes.",
      "Generously spread avocado over toast and drizzle extra virgin olive oil."
    ]
  },
  {
    id: 5,
    name: "Tomato Basil Pasta",
    category: "Dinner",
    time: 25,
    servings: 2,
    price: 140,
    image: "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800",
    description: "Classic Italian pasta tossed in a slow-simmered tomato and fresh basil sauce.",
    calories: 440,
    protein: 14,
    carbs: 72,
    fat: 10,
    ingredients: [
      { name: "Pasta", amount: 200, unit: "g" },
      { name: "Tomatoes", amount: 300, unit: "g" },
      { name: "Olive Oil", amount: 20, unit: "ml" },
      { name: "Garlic", amount: 15, unit: "g" },
      { name: "Fresh Basil", amount: 15, unit: "g" }
    ],
    instructions: [
      "Boil salted water and cook pasta al dente.",
      "Heat olive oil and gently sauté fragrant minced garlic.",
      "Add crushed ripe tomatoes and simmer until rich.",
      "Toss drained pasta in sauce with torn basil leaves."
    ]
  },
  {
    id: 6,
    name: "Golden Vegetable Curry",
    category: "Dinner",
    time: 30,
    servings: 2,
    price: 130,
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=800",
    description: "Vibrant yellow coconut curry simmering with cauliflower, carrots, and sweet peas.",
    calories: 360,
    protein: 9,
    carbs: 32,
    fat: 22,
    ingredients: [
      { name: "Cooking Oil", amount: 20, unit: "ml" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Potatoes", amount: 150, unit: "g" },
      { name: "Carrots", amount: 100, unit: "g" },
      { name: "Coconut Milk", amount: 200, unit: "ml" }
    ],
    instructions: [
      "Sauté diced onions in hot cooking oil until aromatic.",
      "Toss in potatoes and carrots with fragrant turmeric and spices.",
      "Pour coconut milk and simmer until vegetables are tender.",
      "Garnish with cilantro and serve piping hot."
    ]
  },
  {
    id: 7,
    name: "Berry Fruit Pancakes",
    category: "Breakfast",
    time: 20,
    servings: 2,
    price: 120,
    image: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=800",
    description: "Fluffy buttermilk style pancakes served with berries and honey.",
    calories: 420,
    protein: 12,
    carbs: 68,
    fat: 11,
    ingredients: [
      { name: "Flour", amount: 150, unit: "g" },
      { name: "Milk", amount: 150, unit: "ml" },
      { name: "Eggs", amount: 1, unit: "pcs" },
      { name: "Butter", amount: 20, unit: "g" },
      { name: "Honey", amount: 25, unit: "g" }
    ],
    instructions: [
      "Whisk flour, milk, egg, and melted butter into a smooth batter.",
      "Pour ladles onto a buttered skillet over medium heat.",
      "Flip when bubbles appear on the surface.",
      "Stack high and garnish with fresh fruit and honey."
    ]
  },
  {
    id: 8,
    name: "Homestyle Vegetable Pulao",
    category: "Lunch",
    time: 30,
    servings: 2,
    price: 110,
    image: "vegetablepulao.jpg",
    description: "Fragrant basmati rice gently spiced with whole cardamom, cloves and vegetables.",
    calories: 410,
    protein: 11,
    carbs: 70,
    fat: 9,
    ingredients: [
      { name: "Basmati Rice", amount: 200, unit: "g" },
      { name: "Carrots", amount: 80, unit: "g" },
      { name: "Onions", amount: 80, unit: "g" },
      { name: "Cooking Oil", amount: 20, unit: "ml" },
      { name: "Potatoes", amount: 100, unit: "g" }
    ],
    instructions: [
      "Wash and soak long-grain basmati rice for 15 minutes.",
      "Sauté onions and spices in oil until golden.",
      "Add vegetables and sauté for 3 minutes.",
      "Add rice and measured water; simmer tightly covered until grains are fluffy."
    ]
  },
  {
    id: 9,
    name: "French Toast",
    category: "Breakfast",
    time: 15,
    servings: 2,
    price: 95,
    image: "french.jpg",
    description: "Golden bread slices dipped in sweet vanilla milk and eggs, pan-toasted.",
    calories: 390,
    protein: 15,
    carbs: 48,
    fat: 14,
    ingredients: [
      { name: "Bread", amount: 4, unit: "pcs" },
      { name: "Eggs", amount: 2, unit: "pcs" },
      { name: "Milk", amount: 100, unit: "ml" },
      { name: "Butter", amount: 20, unit: "g" },
      { name: "Honey", amount: 20, unit: "g" }
    ],
    instructions: [
      "Whisk fresh farm eggs, milk, cinnamon, and honey together.",
      "Dip each thick bread slice until thoroughly saturated.",
      "Melt butter on a warm griddle and cook both sides to rich amber.",
      "Serve warm with a dusting of cinnamon and honey."
    ]
  },
  {
    id: 10,
    name: "Chole Rice",
    category: "Lunch",
    time: 35,
    servings: 2,
    price: 135,
    image: "chole.jpg",
    description: "Hearty spiced chickpea masala paired with steamed basmati rice.",
    calories: 490,
    protein: 18,
    carbs: 82,
    fat: 10,
    ingredients: [
      { name: "Chickpeas", amount: 200, unit: "g" },
      { name: "Basmati Rice", amount: 150, unit: "g" },
      { name: "Tomatoes", amount: 150, unit: "g" },
      { name: "Onions", amount: 100, unit: "g" },
      { name: "Cooking Oil", amount: 15, unit: "ml" }
    ],
    instructions: [
      "Soak chickpeas overnight and simmer with tea spices until tender.",
      "Prepare onion-tomato gravy with amchur and garam masala.",
      "Simmer chickpeas in sauce until intensely flavorful.",
      "Accompany with hot steamed basmati rice."
    ]
  },
  {
    id: 11,
    name: "Crispy Herb Paneer Bites",
    category: "Snacks",
    time: 15,
    servings: 2,
    price: 115,
    image: "https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800",
    description: "Pan-seared spiced paneer cubes tossed in mint dressing and toasted sesame.",
    calories: 310,
    protein: 19,
    carbs: 8,
    fat: 23,
    ingredients: [
      { name: "Paneer", amount: 200, unit: "g" },
      { name: "Olive Oil", amount: 15, unit: "ml" },
      { name: "Lemons", amount: 1, unit: "pcs" },
      { name: "Fresh Basil", amount: 10, unit: "g" }
    ],
    instructions: [
      "Cut fresh paneer into uniform bite-sized cubes.",
      "Toss with olive oil, sea salt, lemon zest, and ground black pepper.",
      "Sear in a hot non-stick pan until each face develops a golden crust.",
      "Garnish with chopped fresh basil and enjoy immediately."
    ]
  },
  {
    id: 12,
    name: "Greek Yoghurt Fruit Parfait",
    category: "Snacks",
    time: 8,
    servings: 1,
    price: 75,
    image: "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=800",
    description: "Layers of thick strained Greek yoghurt, honeyed granola and fresh mixed berries.",
    calories: 220,
    protein: 14,
    carbs: 32,
    fat: 4,
    ingredients: [
      { name: "Greek Yoghurt", amount: 150, unit: "g" },
      { name: "Mixed Berries", amount: 80, unit: "g" },
      { name: "Honey", amount: 15, unit: "g" }
    ],
    instructions: [
      "Spoon velvety Greek yoghurt into the base of a clear glass.",
      "Layer with plump mixed berries.",
      "Drizzle amber honey over each layer and finish with mint."
    ]
  }
];

const pantry = [
  { id: 1, name: "Paneer", quantity: 400, unit: "g", expiry: "2026-11-23", price: 0.35 },
  { id: 2, name: "Basmati Rice", quantity: 1000, unit: "g", expiry: "2027-04-10", price: 0.09 },
  { id: 3, name: "Cooking Oil", quantity: 1000, unit: "ml", expiry: "2027-02-15", price: 0.18 },
  { id: 4, name: "Onions", quantity: 500, unit: "g", expiry: "2026-11-28", price: 0.04 },
  { id: 5, name: "Eggs", quantity: 6, unit: "pcs", expiry: "2026-11-25", price: 7.0 },
  { id: 6, name: "Tomatoes", quantity: 300, unit: "g", expiry: "2026-11-22", price: 0.05 },
  { id: 7, name: "Milk", quantity: 500, unit: "ml", expiry: "2026-11-24", price: 0.06 },
  { id: 8, name: "Potatoes", quantity: 500, unit: "g", expiry: "2026-12-05", price: 0.03 }
];

module.exports = { recipes, pantry };
