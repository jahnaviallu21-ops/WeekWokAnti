/**
 * WeekWok Shopping Gap Calculator & Categorizer
 */
import { convertToBase } from './pantryEngine.js';

export function calculateShoppingGaps(plan, recipes, pantry, deductionMode = 'SRS_3_3_SCHEDULE') {
  const reqs = {};

  Object.entries(plan).forEach(([k, rId]) => {
    if (!rId) return;
    const r = recipes.find(x => x.id === rId);
    if (!r) return;

    r.ingredients.forEach(ing => {
      const name = ing.name.trim().toLowerCase();
      const base = convertToBase(ing.amount, ing.unit);

      if (!reqs[name]) {
        reqs[name] = { name: ing.name, amount: 0, unit: base.unit };
      }
      if (reqs[name].unit === base.unit) {
        reqs[name].amount += base.amount;
      }
    });
  });

  const missing = [];
  Object.values(reqs).forEach(req => {
    const p = pantry.find(x => x.name.trim().toLowerCase() === req.name.trim().toLowerCase());
    const stock = p ? convertToBase(p.quantity, p.unit).amount : 0;
    const gap = deductionMode === 'SRS_3_3_SCHEDULE' ? req.amount : Math.max(0, req.amount - stock);
    if (gap > 0) {
      missing.push({
        name: req.name,
        amount: gap,
        unit: req.unit,
        price: p?.price || 0.15
      });
    }
  });

  return missing;
}
