/**
 * SRS 3.3 Pantry Stock Deduction Engine
 * Implements Real-Time Scheduling Deductions, Restitutions, and Unit Conversions
 */

export function convertToBase(amount, unit) {
  const num = Number(amount) || 0;
  if (unit === "kg") return { amount: num * 1000, unit: "g" };
  if (unit === "l") return { amount: num * 1000, unit: "ml" };
  return { amount: num, unit };
}

export function formatQuantity(amount, unit) {
  const rounded = Math.round((Number(amount) || 0) * 100) / 100;
  if (unit === "g" && rounded >= 1000) return `${(rounded / 1000).toFixed(1)} kg`;
  if (unit === "ml" && rounded >= 1000) return `${(rounded / 1000).toFixed(1)} L`;
  return `${rounded} ${unit}`;
}

export function deductStockOnSchedule(recipe, pantry, servings = 2) {
  const deductions = [];
  recipe.ingredients.forEach(ing => {
    const needed = convertToBase(ing.amount * servings / recipe.servings, ing.unit);
    const item = pantry.find(p => p.name.trim().toLowerCase() === ing.name.trim().toLowerCase());
    if (item) {
      const cur = convertToBase(item.quantity, item.unit);
      if (cur.unit === needed.unit) {
        const deduct = Math.min(cur.amount, needed.amount);
        item.quantity = Math.max(0, cur.amount - deduct);
        deductions.push({ name: ing.name, amount: deduct, unit: cur.unit });
      }
    }
  });
  return deductions;
}

export function restoreStockOnRemoval(deductions, pantry) {
  deductions.forEach(entry => {
    const item = pantry.find(p => p.name.trim().toLowerCase() === entry.name.trim().toLowerCase());
    if (item) {
      const cur = convertToBase(item.quantity, item.unit);
      if (cur.unit === entry.unit) {
        item.quantity = cur.amount + entry.amount;
      }
    } else {
      pantry.push({
        id: Date.now() + Math.random(),
        name: entry.name,
        quantity: entry.amount,
        unit: entry.unit,
        price: 0.15
      });
    }
  });
}
