/**
 * WeekWok Modular Configuration & Palette Constants
 */
export const PALETTE = {
  ink: "#051F20",
  deep: "#0B2B26",
  forest: "#163832",
  green: "#235347",
  sage: "#8EB69B",
  mint: "#DAF1DE"
};

export const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
export const SLOTS = ["Breakfast", "Lunch", "Dinner"];
export const CATEGORIES = ["Breakfast", "Lunch", "Dinner", "Snacks"];
