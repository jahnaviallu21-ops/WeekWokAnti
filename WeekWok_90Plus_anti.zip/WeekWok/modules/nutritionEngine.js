/**
 * WeekWok Nutritional Intelligence & Budget Calculator
 */

export function calculateMacros(plan, recipes) {
  let calories = 0;
  let protein = 0;
  let carbs = 0;
  let fat = 0;
  let cost = 0;

  Object.values(plan).forEach(id => {
    const r = recipes.find(x => x.id === id);
    if (r) {
      calories += (r.calories || 350);
      protein += (r.protein || 15);
      carbs += (r.carbs || 40);
      fat += (r.fat || 12);
      cost += (r.price || 120);
    }
  });

  return {
    calories,
    dailyCalories: Math.round(calories / 7),
    protein,
    carbs,
    fat,
    cost
  };
}
